/* CR3BP numerical kernel. All state vectors are [x, y, vx, vy] in the
   barycentric, counterclockwise co-rotating frame. No force softening.
   Constants: JPL NAIF gm_de440.tpc, BODY399_GM and BODY301_GM.
   The fixed 384400 km separation is a model choice, not an ephemeris. */
(function(root){
'use strict';
const GM_E=398600.43550702266, GM_M=4902.80011845755, DU=384400;
const MU=GM_M/(GM_E+GM_M), A=1-MU;
const TU=Math.sqrt(DU**3/(GM_E+GM_M)), VU=DU/TU;
const RE=6371/DU, RM=1737.4/DU;
function gravity(x,y) {
 const u=x+MU, v=x-A, re=Math.hypot(u,y), rm=Math.hypot(v,y);
 if(!Number.isFinite(re+rm)||re<1e-12||rm<1e-12) throw new Error('SINGULAR: 非有限坐标或天体中心奇点');
 const a=A/(re*re*re), b=MU/(rm*rm*rm);
 return [-a*u-b*v, -(a+b)*y];
}
function rhs(s){const [x,y,vx,vy]=s, g=gravity(x,y); return [vx,vy,2*vy+x+g[0],-2*vx+y+g[1]];}
function omega(x,y){const re=Math.hypot(x+MU,y),rm=Math.hypot(x-A,y);return .5*(x*x+y*y)+A/re+MU/rm;}
function jacobi(s){return 2*omega(s[0],s[1])-s[2]*s[2]-s[3]*s[3];}
function gradient(x,y){const g=gravity(x,y);return [x+g[0],y+g[1]];}
function hessian(x,y){
 const u=x+MU,v=x-A,re=Math.hypot(u,y),rm=Math.hypot(v,y);
 const a=A/re**3,b=MU/rm**3,c=3*A/re**5,d=3*MU/rm**5;
 return [1-a-b+c*u*u+d*v*v,(c*u+d*v)*y,1-a-b+(c+d)*y*y];
}
// Bracketed scalar solve never crosses a primary; triangular points use
// genuinely two-dimensional Newton iterations, not tabulated coordinates.
function bisect(f,lo,hi){
 let a=f(lo),b=f(hi);if(a*b>=0)throw new Error('ROOT_BRACKET');
 let mid=(lo+hi)/2,iterations=0;
 for(;iterations<100;iterations++){
  mid=(lo+hi)/2;const v=f(mid);
  if(Math.abs(v)<2e-15 || Math.abs(hi-lo)<5e-16)break;
  if(a*v<=0){hi=mid;b=v;}else{lo=mid;a=v;}
 }
 return {x:mid,iterations:iterations+1};
}
function lagrangePoints(){
 const f=x=>gradient(x,0)[0],eps=1e-7;
 const brackets=[[-MU+eps,A-eps],[A+eps,3],[-3,-MU-eps]];
 const points=brackets.map((b,i)=>{const z=bisect(f,...b);return {name:'L'+(i+1),x:z.x,y:0,iterations:z.iterations};});
 for(const sign of [1,-1]){
  let x=.43,y=sign*.78,it=0;
  for(;it<30;it++){
   const [gx,gy]=gradient(x,y),[xx,xy,yy]=hessian(x,y),det=xx*yy-xy*xy;
   if(Math.hypot(gx,gy)<1e-15)break;
   if(Math.abs(det)<1e-16)throw new Error('ROOT_JACOBIAN');
   x-=(yy*gx-xy*gy)/det;y-=(-xy*gx+xx*gy)/det;
  }
  points.push({name:sign>0?'L4':'L5',x,y,iterations:it+1});
 }
 return points.map(p=>({...p,residual:Math.hypot(...gradient(p.x,p.y)),C:2*omega(p.x,p.y)}));
}
function rk4(s,h){
 const k1=rhs(s),k2=rhs(s.map((v,i)=>v+h*.5*k1[i]));
 const k3=rhs(s.map((v,i)=>v+h*.5*k2[i])),k4=rhs(s.map((v,i)=>v+h*k3[i]));
 return s.map((v,i)=>v+h/6*(k1[i]+2*k2[i]+2*k3[i]+k4[i]));
}
function integrate(s,h,n,method='rk4'){
 const fn=method==='rk4'?rk4:sy4;let z=s.slice(),maxDrift=0,C0=jacobi(s);
 for(let i=0;i<n;i++){z=fn(z,h);maxDrift=Math.max(maxDrift,Math.abs(jacobi(z)-C0));}
 return {state:z,maxDrift,C0,steps:n,time:h*n};
}
function normDiff(a,b){return Math.hypot(...a.map((v,i)=>v-b[i]));}
function convergence(method,s=[.5,.7,.1,-.1],T=2,h=.02){
 const run=[h,h/2,h/4].map(dt=>integrate(s,dt,Math.round(T/dt),method));
 const d1=normDiff(run[0].state,run[1].state),d2=normDiff(run[1].state,run[2].state);
 return {method,T,h,d1,d2,ratio:d1/d2,order:Math.log2(d1/d2),drifts:run.map(r=>r.maxDrift)};
}
const API={rk4,integrate,normDiff,convergence,bisect,lagrangePoints,GM_E,GM_M,DU,MU,A,TU,VU,RE,RM,gravity,rhs,omega,jacobi,gradient,hessian};
if(typeof module!=='undefined'&&module.exports) module.exports=API;root.CR3BP=API;
})(typeof globalThis!=='undefined'?globalThis:this);
