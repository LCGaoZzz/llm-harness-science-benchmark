/* LAGRANGE UI: numerical state, cached potential field, renderer, controller.
   Canvas never supplies dynamics; only CR3BP.guardedStep advances the state. */
(function(){
'use strict';
const P=CR3BP,$=id=>document.getElementById(id),L=P.lagrangePoints(),presets=P.presets();
const canvas=$('scene'),ctx=canvas.getContext('2d'),fieldCanvas=document.createElement('canvas'),fc=fieldCanvas.getContext('2d');
const settings={method:'sy4',h:presets.l1.h,rate:presets.l1.rate,zvc:true,forbidden:true,lp:true,velocity:true,boundaryMode:'initial',manualC:3.188341};
let initial=presets.l1.state.slice(),state=initial.slice(),time=0,C0=P.jacobi(initial),steps=0,paused=true,presetId='l1',maxDrift=0,minMoon=Math.hypot(state[0]-P.A,state[1])*P.DU-1737.4;
let history=[{t:0,s:state.slice(),C:C0}],driftHistory=[{t:0,d:0}],dropped=0,sampleStride=1;
const view={x:.1,y:0,span:3.2};let width=1,height=1,dpr=1,scale=1,fieldDirty=true,segments=[],gridInfo={},fps=0,lastFrame=0;
function worldToScreen(x,y){return [(x-view.x)*scale+width/2,height/2-(y-view.y)*scale];}
function screenToWorld(x,y){return [(x-width/2)/scale+view.x,(height/2-y)/scale+view.y];}
function boundaryC(){if(settings.boundaryMode==='initial')return C0;if(settings.boundaryMode==='manual')return settings.manualC;return L.find(p=>p.name===settings.boundaryMode).C;}
function resize(){
 const r=$('viewport').getBoundingClientRect();if(r.width<1||r.height<1)return;
 width=r.width;height=r.height;dpr=Math.min(window.devicePixelRatio||1,2);scale=width/view.span;
 canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);
 fieldCanvas.width=Math.round(width*dpr);fieldCanvas.height=Math.round(height*dpr);fc.setTransform(dpr,0,0,dpr,0,0);fieldDirty=true;
}
function contourSegments(nx,ny,values,at,C){
 const out=[];
 function crossing(a,b,fa,fb){
  let lo=0,hi=1;for(let i=0;i<18;i++){let m=(lo+hi)/2,[x,y]=screenToWorld(a[0]+m*(b[0]-a[0]),a[1]+m*(b[1]-a[1]));let f=2*P.omega(x,y)-C;if((f>=0)===(fa>=0))lo=m;else hi=m;}
  const t=(lo+hi)/2;return [a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])];
 }
 // TL,TR,BR,BL corners. Edge 0=top,1=right,2=bottom,3=left.
 for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){
  const f=[values[j*(nx+1)+i],values[j*(nx+1)+i+1],values[(j+1)*(nx+1)+i+1],values[(j+1)*(nx+1)+i]];
  const a=[at(i,j),at(i+1,j),at(i+1,j+1),at(i,j+1)],e=[];
  for(let k=0;k<4;k++)if((f[k]>=0)!==(f[(k+1)%4]>=0))e.push([k,crossing(a[k],a[(k+1)%4],f[k],f[(k+1)%4])]);
  if(e.length===2)out.push([e[0][1],e[1][1]]);
  else if(e.length===4){
   const [cx,cy]=screenToWorld((a[0][0]+a[2][0])/2,(a[0][1]+a[2][1])/2);
   if((2*P.omega(cx,cy)-C>=0)===(f[0]>=0)){out.push([e[0][1],e[1][1]],[e[2][1],e[3][1]]);}
   else out.push([e[0][1],e[3][1]],[e[1][1],e[2][1]]);
  }
 }
 return out;
}
function updateField(){
 const C=boundaryC(),nx=Math.ceil(width/4),ny=Math.ceil(height/4),dx=width/nx,dy=height/ny;
 fc.clearRect(0,0,width,height);segments=[];
 if(!settings.zvc&&!settings.forbidden){fieldDirty=false;return;}
 const vals=new Float64Array((nx+1)*(ny+1));
 for(let j=0;j<=ny;j++)for(let i=0;i<=nx;i++){
  const [x,y]=screenToWorld(i*dx,j*dy);vals[j*(nx+1)+i]=2*P.omega(x,y)-C;
 }
 if(settings.forbidden){
  fc.fillStyle='rgba(113,75,104,0.17)';
  for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){
   const [x,y]=screenToWorld((i+.5)*dx,(j+.5)*dy);
   if(2*P.omega(x,y)-C<0)fc.fillRect(i*dx,j*dy,dx+.5,dy+.5);
  }
 }
 if(settings.zvc){
  segments=contourSegments(nx,ny,vals,(i,j)=>[i*dx,j*dy],C);
  fc.strokeStyle='rgba(221,186,117,.8)';fc.lineWidth=1;fc.beginPath();
  for(const [a,b] of segments){fc.moveTo(...a);fc.lineTo(...b);}fc.stroke();
 }
 gridInfo={nx,ny,pixels:4,segments:segments.length};
 $('contourLabel').textContent=(settings.boundaryMode==='initial'?'C₀':'C边界')+' = '+C.toFixed(9);
 $('boundaryNote').textContent=Math.abs(C-C0)>1e-10?'独立参考边界 · 与本轨迹 C₀ 不同':(C<L[3].C-1e-12?'C < C(L4) · 此水平无禁止区':'禁止区域满足 2Ω − C < 0');
 $('boundaryValue').value=C.toPrecision(12);fieldDirty=false;
}
function niceStep(raw){const e=10**Math.floor(Math.log10(raw));return [1,2,5,10].find(a=>a*e>=raw)*e;}
function renderGrid(){
 const step=niceStep(85/scale),[xmin,ymax]=screenToWorld(0,0),[xmax,ymin]=screenToWorld(width,height);
 ctx.lineWidth=.6;ctx.strokeStyle='#1a2a3b';ctx.beginPath();
 for(let x=Math.ceil(xmin/step)*step;x<=xmax;x+=step){const p=worldToScreen(x,0)[0];ctx.moveTo(p,0);ctx.lineTo(p,height);}
 for(let y=Math.ceil(ymin/step)*step;y<=ymax;y+=step){const p=worldToScreen(0,y)[1];ctx.moveTo(0,p);ctx.lineTo(width,p);}ctx.stroke();
 ctx.strokeStyle='#344256';ctx.setLineDash([3,5]);const o=worldToScreen(0,0);ctx.beginPath();ctx.moveTo(0,o[1]);ctx.lineTo(width,o[1]);ctx.moveTo(o[0],0);ctx.lineTo(o[0],height);ctx.stroke();ctx.setLineDash([]);
 ctx.fillStyle='#50667f';ctx.font='9px Consolas, monospace';ctx.textAlign='center';
 for(let x=Math.ceil(xmin/step)*step;x<xmax;x+=step){const p=worldToScreen(x,0);if(Math.abs(x)>.001)ctx.fillText(x.toFixed(step<.1?2:1),p[0],Math.min(height-45,Math.max(18,o[1]+17)));}
 ctx.textAlign='left';for(let y=Math.ceil(ymin/step)*step;y<ymax;y+=step){if(Math.abs(y)<.001)continue;const p=worldToScreen(0,y);ctx.fillText(y.toFixed(step<.1?2:1),Math.min(width-37,Math.max(8,o[0]+6)),p[1]-6);}
 const ruler=niceStep(70/scale),rw=ruler*scale;ctx.strokeStyle='#6c8098';ctx.beginPath();ctx.moveTo(width-20-rw,height-45);ctx.lineTo(width-20,height-45);ctx.moveTo(width-20-rw,height-48);ctx.lineTo(width-20-rw,height-42);ctx.moveTo(width-20,height-48);ctx.lineTo(width-20,height-42);ctx.stroke();
 $('scaleLabel').textContent=ruler.toPrecision(2)+' DU / '+(ruler*P.DU).toLocaleString('en-US',{maximumFractionDigits:0})+' km';
}
function body(x,y,r,label,color){
 const [sx,sy]=worldToScreen(x,y),radius=Math.max(r*scale,label==='EARTH'?7:4);
 if(sx<-50||sy<-50||sx>width+50||sy>height+50)return;
 const g=ctx.createRadialGradient(sx,sy,0,sx,sy,radius*3.5);g.addColorStop(0,color+'55');g.addColorStop(1,color+'00');ctx.fillStyle=g;ctx.beginPath();ctx.arc(sx,sy,radius*3.5,0,Math.PI*2);ctx.fill();
 const g2=ctx.createRadialGradient(sx-radius*.35,sy-radius*.4,0,sx,sy,radius);g2.addColorStop(0,label==='EARTH'?'#aacffa':'#e8e4da');g2.addColorStop(.4,color);g2.addColorStop(1,label==='EARTH'?'#244a72':'#4a5362');
 ctx.fillStyle=g2;ctx.beginPath();ctx.arc(sx,sy,radius,0,Math.PI*2);ctx.fill();ctx.strokeStyle=color+'99';ctx.lineWidth=.7;ctx.stroke();
 ctx.font='10px Consolas, monospace';ctx.fillStyle=color;ctx.textAlign='center';ctx.fillText(label,sx,sy+radius+19);
}
function renderPoints(){
 if(!settings.lp)return;
 for(const p of L){const [x,y]=worldToScreen(p.x,p.y);if(x<-20||y<-20||x>width+20||y>height+20)continue;
  const stable=p.name==='L4'||p.name==='L5';ctx.strokeStyle=stable?'#4b998b':'#8792ac';ctx.lineWidth=.9;
  ctx.beginPath();ctx.moveTo(x-5,y);ctx.lineTo(x+5,y);ctx.moveTo(x,y-5);ctx.lineTo(x,y+5);ctx.stroke();ctx.beginPath();ctx.arc(x,y,10,0,Math.PI*2);ctx.strokeStyle=stable?'#254a49':'#293648';ctx.stroke();
  ctx.font='11px Consolas, monospace';ctx.textAlign='center';ctx.fillStyle=stable?'#80bfab':'#a1b3cc';ctx.fillText(p.name,x,y-16);
 }
}
function renderTrajectory(){
 if(history.length>1){ctx.strokeStyle='#62e0bf';ctx.lineWidth=1.45;ctx.lineJoin='round';ctx.beginPath();
  history.forEach((p,i)=>{const q=worldToScreen(p.s[0],p.s[1]);if(i===0)ctx.moveTo(...q);else ctx.lineTo(...q)});ctx.lineTo(...worldToScreen(state[0],state[1]));ctx.stroke();}
 const a=worldToScreen(initial[0],initial[1]);ctx.strokeStyle='#498478';ctx.lineWidth=1;ctx.beginPath();ctx.arc(...a,3,0,Math.PI*2);ctx.stroke();
 const [x,y]=worldToScreen(state[0],state[1]);if(x<-30||y<-30||x>width+30||y>height+30)return;
 const sp=Math.hypot(state[2],state[3]);
 if(settings.velocity&&sp>1e-10){const dx=state[2]/sp,dy=-state[3]/sp,len=31,xx=x+len*dx,yy=y+len*dy;ctx.strokeStyle='#68a99e';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(xx,yy);ctx.moveTo(xx-6*dx+3*dy,yy-6*dy-3*dx);ctx.lineTo(xx,yy);ctx.lineTo(xx-6*dx-3*dy,yy-6*dy+3*dx);ctx.stroke();}
 ctx.shadowBlur=13;ctx.shadowColor='#62e0bf';ctx.fillStyle='#97ffe3';ctx.beginPath();ctx.arc(x,y,3,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
 ctx.font='9px Consolas, monospace';ctx.textAlign='left';ctx.fillStyle='#70bca9';ctx.fillText('SC',x+9,y+17);
}
function render(){
 if(fieldDirty)updateField();ctx.fillStyle='#080e18';ctx.fillRect(0,0,width,height);renderGrid();
 ctx.drawImage(fieldCanvas,0,0,fieldCanvas.width,fieldCanvas.height,0,0,width,height);
 renderTrajectory();body(-P.MU,0,P.RE,'EARTH','#739ed3');body(P.A,0,P.RM,'MOON','#b4bdcc');renderPoints();
}
function driftPlot(){
 const c=$('driftChart'),r=c.getBoundingClientRect();if(r.width<1)return;const d=Math.min(devicePixelRatio||1,2);if(c.width!==Math.round(r.width*d)||c.height!==Math.round(r.height*d)){c.width=Math.round(r.width*d);c.height=Math.round(r.height*d);}
 const g=c.getContext('2d');g.setTransform(d,0,0,d,0,0);const w=r.width,h=r.height,range=Math.max(1e-15,...driftHistory.map(a=>Math.abs(a.d)))*1.15;
 g.clearRect(0,0,w,h);g.strokeStyle='#2b414b';g.lineWidth=.8;g.setLineDash([3,4]);g.beginPath();g.moveTo(0,h/2);g.lineTo(w,h/2);g.stroke();g.setLineDash([]);
 if(driftHistory.length>1){g.strokeStyle='#62bda9';g.lineWidth=1.2;g.beginPath();const t0=driftHistory[0].t,t1=driftHistory[driftHistory.length-1].t;driftHistory.forEach((p,i)=>{const x=(p.t-t0)/(t1-t0||1)*w,y=h/2-p.d/range*(h*.42);i?g.lineTo(x,y):g.moveTo(x,y)});g.stroke();}
 $('driftRange').textContent='± '+range.toExponential(1);
}
function telemetry(){
 const C=P.jacobi(state),drift=C-C0,rel=Math.abs(drift)/Math.max(1,Math.abs(C0));
 $('time').textContent=time.toFixed(4);$('physicalTime').textContent=(time*P.TU/86400).toFixed(3)+' 天 · '+(time/(2*Math.PI)).toFixed(3)+' 月轨道周期';
 ['sx','sy','svx','svy'].forEach((id,i)=>$(id).textContent=state[i].toFixed(7));
 $('speed').textContent=(Math.hypot(state[2],state[3])*P.VU).toFixed(5)+' km/s';$('inertialSpeed').textContent=(Math.hypot(...P.canonical(state).slice(2))*P.VU).toFixed(5)+' km/s';
 $('jacobi').textContent=C.toFixed(11);$('drift').textContent=(drift>=0?'+':'')+drift.toExponential(3);$('maxDrift').textContent=maxDrift.toExponential(3);$('relativeDrift').textContent=rel.toExponential(2);
 $('drift').classList.toggle('warn',rel>1e-7);$('maxDrift').classList.toggle('warn',maxDrift/Math.max(1,Math.abs(C0))>1e-7);
 $('distEarth').textContent=(Math.hypot(state[0]+P.MU,state[1])*P.DU).toLocaleString('en-US',{maximumFractionDigits:0})+' km';$('distMoon').textContent=(Math.hypot(state[0]-P.A,state[1])*P.DU).toLocaleString('en-US',{maximumFractionDigits:0})+' km';$('minMoon').textContent=minMoon.toLocaleString('en-US',{maximumFractionDigits:0})+' km';
 $('perfLabel').textContent='h = '+settings.h+' · '+steps.toLocaleString('en-US')+' steps';$('fpsLabel').textContent=fps.toFixed(0)+' FPS';driftPlot();
}
function populate(){
 $('lpRows').innerHTML=L.map(p=>'<tr title="'+p.name+' 残差 '+p.residual.toExponential(3)+'；'+p.iterations+' 次迭代"><td>'+p.name+'</td><td>'+p.x.toFixed(6)+'</td><td>'+p.y.toFixed(6)+'</td></tr>').join('');
 $('residualText').textContent='max |∇Ω| = '+Math.max(...L.map(p=>p.residual)).toExponential(3);
 $('muLabel').textContent=P.MU.toFixed(12);$('unitDetails').textContent='1 TU = '+P.TU.toFixed(3)+' s = '+(P.TU/86400).toFixed(6)+' d；1 VU = '+P.VU.toFixed(9)+' km/s。';
 ['x0','y0','vx0','vy0'].forEach((id,i)=>$(id).value=initial[i].toPrecision(16));$('presetDescription').textContent=presets[presetId].description;
}
/*__CONTROLLER__*/
populate();resize();telemetry();render();new ResizeObserver(()=>{resize();render();telemetry()}).observe($('viewport'));
// Public, read-only snapshots support reproducible browser verification.
window.Lab={physics:P,lagrange:L,getSnapshot:()=>({state:state.slice(),initial:initial.slice(),time,C0,steps,paused,method:settings.method,h:settings.h,rate:settings.rate,maxDrift,minMoon,historyLength:history.length,dropped,sampleStride,view:{...view},grid:{...gridInfo},boundaryC:boundaryC(),preset:presetId}),render,screenToWorld,worldToScreen,contourSegments};
})();
