/* CR3BP numerical kernel. All state vectors are [x, y, vx, vy] in the
   barycentric, counterclockwise co-rotating frame. No force softening.
   Constants: JPL NAIF gm_de440.tpc, BODY399_GM and BODY301_GM.
   The fixed 384400 km separation is a model choice, not an ephemeris. */
(function(root){
'use strict';
const GM_E=398600.43550702266, GM_M=4902.80011845755, DU=384400;
const MU=GM_M/(GM_E+GM_M), A=1-MU;
const TU=Math.sqrt(DU**3/(GM_E+GM_M)), VU=DU/TU;
const RE=6371/DU, RM=1737.4/DU;
function gravity(x,y) {
 const u=x+MU, v=x-A, re=Math.hypot(u,y), rm=Math.hypot(v,y);
 if(!Number.isFinite(re+rm)||re<1e-12||rm<1e-12) throw new Error('SINGULAR: 非有限坐标或天体中心奇点');
 const a=A/(re*re*re), b=MU/(rm*rm*rm);
 return [-a*u-b*v, -(a+b)*y];
}
function rhs(s){const [x,y,vx,vy]=s, g=gravity(x,y); return [vx,vy,2*vy+x+g[0],-2*vx+y+g[1]];}
function omega(x,y){const re=Math.hypot(x+MU,y),rm=Math.hypot(x-A,y);return .5*(x*x+y*y)+A/re+MU/rm;}
function jacobi(s){return 2*omega(s[0],s[1])-s[2]*s[2]-s[3]*s[3];}
function gradient(x,y){const g=gravity(x,y);return [x+g[0],y+g[1]];}
function hessian(x,y){
 const u=x+MU,v=x-A,re=Math.hypot(u,y),rm=Math.hypot(v,y);
 const a=A/re**3,b=MU/rm**3,c=3*A/re**5,d=3*MU/rm**5;
 return [1-a-b+c*u*u+d*v*v,(c*u+d*v)*y,1-a-b+(c+d)*y*y];
}
const API={GM_E,GM_M,DU,MU,A,TU,VU,RE,RM,gravity,rhs,omega,jacobi,gradient,hessian};
if(typeof module!=='undefined'&&module.exports) module.exports=API;root.CR3BP=API;
})(typeof globalThis!=='undefined'?globalThis:this);
