/* LAGRANGE UI: numerical state, cached potential field, renderer, controller.
   Canvas never supplies dynamics; only CR3BP.guardedStep advances the state. */
(function(){
'use strict';
const P=CR3BP,$=id=>document.getElementById(id),L=P.lagrangePoints(),presets=P.presets();
const canvas=$('scene'),ctx=canvas.getContext('2d'),fieldCanvas=document.createElement('canvas'),fc=fieldCanvas.getContext('2d');
const settings={method:'sy4',h:presets.l1.h,rate:presets.l1.rate,zvc:true,forbidden:true,lp:true,velocity:true,boundaryMode:'initial',manualC:3.188341};
let initial=presets.l1.state.slice(),state=initial.slice(),time=0,C0=P.jacobi(initial),steps=0,paused=true,presetId='l1',maxDrift=0,minMoon=Math.hypot(state[0]-P.A,state[1])*P.DU-1737.4;
let history=[{t:0,s:state.slice(),C:C0}],driftHistory=[{t:0,d:0}],dropped=0,sampleStride=1;
const view={x:.1,y:0,span:3.2,mode:'global'};let width=1,height=1,dpr=1,scale=1,fieldDirty=true,segments=[],gridInfo={},fps=0,lastFrame=0;
function worldToScreen(x,y){return [(x-view.x)*scale+width/2,height/2-(y-view.y)*scale];}
function screenToWorld(x,y){return [(x-width/2)/scale+view.x,(height/2-y)/scale+view.y];}
function boundaryC(){if(settings.boundaryMode==='initial')return C0;if(settings.boundaryMode==='manual')return settings.manualC;return L.find(p=>p.name===settings.boundaryMode).C;}
function resize(){
 const r=$('viewport').getBoundingClientRect();if(r.width<1||r.height<1)return;
 width=r.width;height=r.height;if(view.mode==='global')view.span=Math.max(3.2,2.65*width/height);dpr=Math.min(window.devicePixelRatio||1,2);scale=width/view.span;
 canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);
 fieldCanvas.width=Math.round(width*dpr);fieldCanvas.height=Math.round(height*dpr);fc.setTransform(dpr,0,0,dpr,0,0);fieldDirty=true;
}
function contourSegments(nx,ny,values,at,C){
 const out=[];
 function crossing(a,b,fa,fb){
  let lo=0,hi=1;for(let i=0;i<30;i++){let m=(lo+hi)/2,[x,y]=screenToWorld(a[0]+m*(b[0]-a[0]),a[1]+m*(b[1]-a[1]));let f=2*P.omega(x,y)-C;if((f>=0)===(fa>=0))lo=m;else hi=m;}
  const t=(lo+hi)/2;return [a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])];
 }
 // TL,TR,BR,BL corners. Edge 0=top,1=right,2=bottom,3=left.
 for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){
  const f=[values[j*(nx+1)+i],values[j*(nx+1)+i+1],values[(j+1)*(nx+1)+i+1],values[(j+1)*(nx+1)+i]];
  const a=[at(i,j),at(i+1,j),at(i+1,j+1),at(i,j+1)],e=[];
  for(let k=0;k<4;k++)if((f[k]>=0)!==(f[(k+1)%4]>=0))e.push([k,crossing(a[k],a[(k+1)%4],f[k],f[(k+1)%4])]);
  if(e.length===2)out.push([e[0][1],e[1][1]]);
  else if(e.length===4){
   const [cx,cy]=screenToWorld((a[0][0]+a[2][0])/2,(a[0][1]+a[2][1])/2);
   if((2*P.omega(cx,cy)-C>=0)===(f[0]>=0)){out.push([e[0][1],e[1][1]],[e[2][1],e[3][1]]);}
   else out.push([e[0][1],e[3][1]],[e[1][1],e[2][1]]);
  }
 }
 return out;
}
function updateField(){
 const C=boundaryC(),nx=Math.ceil(width/4),ny=Math.ceil(height/4),dx=width/nx,dy=height/ny;
 fc.clearRect(0,0,width,height);segments=[];
 $('contourLabel').textContent=(settings.boundaryMode==='initial'?'C₀':'C边界')+' = '+C.toFixed(9);
 $('boundaryNote').textContent=Math.abs(C-C0)>1e-10?'独立参考边界 · 与本轨迹 C₀ 不同':(C<L[3].C-1e-12?'C < C(L4) · 此水平无禁止区':'禁止区域满足 2Ω − C < 0');
 $('boundaryValue').value=C.toPrecision(12);
 if(!settings.zvc&&!settings.forbidden){gridInfo={nx,ny,pixels:4,segments:0};fieldDirty=false;return;}
 const vals=new Float64Array((nx+1)*(ny+1));
 for(let j=0;j<=ny;j++)for(let i=0;i<=nx;i++){
  const [x,y]=screenToWorld(i*dx,j*dy);vals[j*(nx+1)+i]=2*P.omega(x,y)-C;
 }
 if(settings.forbidden){
  fc.fillStyle='rgba(113,75,104,0.17)';
  for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){
   const [x,y]=screenToWorld((i+.5)*dx,(j+.5)*dy);
   if(2*P.omega(x,y)-C<0)fc.fillRect(i*dx,j*dy,dx+.5,dy+.5);
  }
 }
 if(settings.zvc){
  segments=contourSegments(nx,ny,vals,(i,j)=>[i*dx,j*dy],C);
  fc.strokeStyle='rgba(221,186,117,.8)';fc.lineWidth=1;fc.beginPath();
  for(const [a,b] of segments){fc.moveTo(...a);fc.lineTo(...b);}fc.stroke();
 }
 gridInfo={nx,ny,pixels:4,segments:segments.length};
fieldDirty=false;
}
function niceStep(raw){const e=10**Math.floor(Math.log10(raw));return [1,2,5,10].find(a=>a*e>=raw)*e;}
function renderGrid(){
 const step=niceStep(85/scale),[xmin,ymax]=screenToWorld(0,0),[xmax,ymin]=screenToWorld(width,height);
 ctx.lineWidth=.6;ctx.strokeStyle='#1a2a3b';ctx.beginPath();
 for(let x=Math.ceil(xmin/step)*step;x<=xmax;x+=step){const p=worldToScreen(x,0)[0];ctx.moveTo(p,0);ctx.lineTo(p,height);}
 for(let y=Math.ceil(ymin/step)*step;y<=ymax;y+=step){const p=worldToScreen(0,y)[1];ctx.moveTo(0,p);ctx.lineTo(width,p);}ctx.stroke();
 ctx.strokeStyle='#344256';ctx.setLineDash([3,5]);const o=worldToScreen(0,0);ctx.beginPath();ctx.moveTo(0,o[1]);ctx.lineTo(width,o[1]);ctx.moveTo(o[0],0);ctx.lineTo(o[0],height);ctx.stroke();ctx.setLineDash([]);
 ctx.fillStyle='#50667f';ctx.font='9px Consolas, monospace';ctx.textAlign='center';
 for(let x=Math.ceil(xmin/step)*step;x<xmax;x+=step){const p=worldToScreen(x,0);if(Math.abs(x)>.001&&Math.abs(x-P.A)*scale>26&&Math.abs(x+P.MU)*scale>26)ctx.fillText(x.toFixed(step<.1?2:1),p[0],Math.min(height-45,Math.max(18,o[1]+17)));}
 ctx.textAlign='left';for(let y=Math.ceil(ymin/step)*step;y<ymax;y+=step){if(Math.abs(y)<.001)continue;const p=worldToScreen(0,y);ctx.fillText(y.toFixed(step<.1?2:1),Math.min(width-37,Math.max(8,o[0]+6)),p[1]-6);}
 const ruler=niceStep(70/scale),rw=ruler*scale;ctx.strokeStyle='#6c8098';ctx.beginPath();ctx.moveTo(width-20-rw,height-45);ctx.lineTo(width-20,height-45);ctx.moveTo(width-20-rw,height-48);ctx.lineTo(width-20-rw,height-42);ctx.moveTo(width-20,height-48);ctx.lineTo(width-20,height-42);ctx.stroke();
 $('scaleLabel').textContent=ruler.toPrecision(2)+' DU / '+(ruler*P.DU).toLocaleString('en-US',{maximumFractionDigits:0})+' km';
}
function body(x,y,r,label,color){
 const [sx,sy]=worldToScreen(x,y),radius=Math.max(r*scale,label==='EARTH'?7:4);
 if(sx<-50||sy<-50||sx>width+50||sy>height+50)return;
 const g=ctx.createRadialGradient(sx,sy,0,sx,sy,radius*3.5);g.addColorStop(0,color+'55');g.addColorStop(1,color+'00');ctx.fillStyle=g;ctx.beginPath();ctx.arc(sx,sy,radius*3.5,0,Math.PI*2);ctx.fill();
 const g2=ctx.createRadialGradient(sx-radius*.35,sy-radius*.4,0,sx,sy,radius);g2.addColorStop(0,label==='EARTH'?'#aacffa':'#e8e4da');g2.addColorStop(.4,color);g2.addColorStop(1,label==='EARTH'?'#244a72':'#4a5362');
 ctx.fillStyle=g2;ctx.beginPath();ctx.arc(sx,sy,radius,0,Math.PI*2);ctx.fill();ctx.strokeStyle=color+'99';ctx.lineWidth=.7;ctx.stroke();
 ctx.font='10px Consolas, monospace';ctx.fillStyle=color;ctx.textAlign='center';ctx.fillText(label,sx,sy+radius+19);
}
function renderPoints(){
 if(!settings.lp)return;
 for(const p of L){const [x,y]=worldToScreen(p.x,p.y);if(x<-20||y<-20||x>width+20||y>height+20)continue;
  const stable=p.name==='L4'||p.name==='L5';ctx.strokeStyle=stable?'#4b998b':'#8792ac';ctx.lineWidth=.9;
  ctx.beginPath();ctx.moveTo(x-5,y);ctx.lineTo(x+5,y);ctx.moveTo(x,y-5);ctx.lineTo(x,y+5);ctx.stroke();ctx.beginPath();ctx.arc(x,y,10,0,Math.PI*2);ctx.strokeStyle=stable?'#254a49':'#293648';ctx.stroke();
  ctx.font='11px Consolas, monospace';ctx.textAlign='center';ctx.fillStyle=stable?'#80bfab':'#a1b3cc';ctx.fillText(p.name,x,y-16);
 }
}
function renderTrajectory(){
 if(history.length>1){ctx.strokeStyle='#62e0bf';ctx.lineWidth=1.45;ctx.lineJoin='round';ctx.beginPath();
  history.forEach((p,i)=>{const q=worldToScreen(p.s[0],p.s[1]);if(i===0)ctx.moveTo(...q);else ctx.lineTo(...q)});ctx.lineTo(...worldToScreen(state[0],state[1]));ctx.stroke();}
 const a=worldToScreen(initial[0],initial[1]);ctx.strokeStyle='#498478';ctx.lineWidth=1;ctx.beginPath();ctx.arc(...a,3,0,Math.PI*2);ctx.stroke();
 const [x,y]=worldToScreen(state[0],state[1]);if(x<-30||y<-30||x>width+30||y>height+30)return;
 const sp=Math.hypot(state[2],state[3]);
 if(settings.velocity&&sp>1e-10){const dx=state[2]/sp,dy=-state[3]/sp,len=31,xx=x+len*dx,yy=y+len*dy;ctx.strokeStyle='#68a99e';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(xx,yy);ctx.moveTo(xx-6*dx+3*dy,yy-6*dy-3*dx);ctx.lineTo(xx,yy);ctx.lineTo(xx-6*dx-3*dy,yy-6*dy+3*dx);ctx.stroke();}
 ctx.shadowBlur=13;ctx.shadowColor='#62e0bf';ctx.fillStyle='#97ffe3';ctx.beginPath();ctx.arc(x,y,3,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
 ctx.font='9px Consolas, monospace';ctx.textAlign='left';ctx.fillStyle='#70bca9';ctx.fillText('SC',x+9,y+17);
}
function render(){
 if(fieldDirty)updateField();ctx.fillStyle='#080e18';ctx.fillRect(0,0,width,height);renderGrid();
 ctx.drawImage(fieldCanvas,0,0,fieldCanvas.width,fieldCanvas.height,0,0,width,height);
 renderTrajectory();body(-P.MU,0,P.RE,'EARTH','#739ed3');body(P.A,0,P.RM,'MOON','#b4bdcc');renderPoints();
}
function driftPlot(){
 const c=$('driftChart'),r=c.getBoundingClientRect();if(r.width<1)return;const d=Math.min(devicePixelRatio||1,2);if(c.width!==Math.round(r.width*d)||c.height!==Math.round(r.height*d)){c.width=Math.round(r.width*d);c.height=Math.round(r.height*d);}
 const g=c.getContext('2d');g.setTransform(d,0,0,d,0,0);const w=r.width,h=r.height,range=Math.max(1e-15,...driftHistory.map(a=>Math.abs(a.d)))*1.15;
 g.clearRect(0,0,w,h);g.strokeStyle='#2b414b';g.lineWidth=.8;g.setLineDash([3,4]);g.beginPath();g.moveTo(0,h/2);g.lineTo(w,h/2);g.stroke();g.setLineDash([]);
 if(driftHistory.length>1){g.strokeStyle='#62bda9';g.lineWidth=1.2;g.beginPath();const t0=driftHistory[0].t,t1=driftHistory[driftHistory.length-1].t;driftHistory.forEach((p,i)=>{const x=(p.t-t0)/(t1-t0||1)*w,y=h/2-p.d/range*(h*.42);i?g.lineTo(x,y):g.moveTo(x,y)});g.stroke();}
 $('driftRange').textContent='± '+range.toExponential(1);
}
function telemetry(){
 const C=P.jacobi(state),drift=C-C0,rel=Math.abs(drift)/Math.max(1,Math.abs(C0));
 $('time').textContent=time.toFixed(4);$('physicalTime').textContent=(time*P.TU/86400).toFixed(3)+' 天 · '+(time/(2*Math.PI)).toFixed(3)+' 月轨道周期';
 ['sx','sy','svx','svy'].forEach((id,i)=>$(id).textContent=state[i].toFixed(7));
 $('speed').textContent=(Math.hypot(state[2],state[3])*P.VU).toFixed(5)+' km/s';$('inertialSpeed').textContent=(Math.hypot(...P.canonical(state).slice(2))*P.VU).toFixed(5)+' km/s';
 $('jacobi').textContent=C.toFixed(11);$('drift').textContent=(drift>=0?'+':'')+drift.toExponential(3);$('maxDrift').textContent=maxDrift.toExponential(3);$('relativeDrift').textContent=rel.toExponential(2);
 $('drift').classList.toggle('warn',rel>1e-7);$('maxDrift').classList.toggle('warn',maxDrift/Math.max(1,Math.abs(C0))>1e-7);
 $('distEarth').textContent=(Math.hypot(state[0]+P.MU,state[1])*P.DU).toLocaleString('en-US',{maximumFractionDigits:0})+' km';$('distMoon').textContent=(Math.hypot(state[0]-P.A,state[1])*P.DU).toLocaleString('en-US',{maximumFractionDigits:0})+' km';$('minMoon').textContent=minMoon.toLocaleString('en-US',{maximumFractionDigits:0})+' km';
 $('perfLabel').textContent='h = '+settings.h+' · '+steps.toLocaleString('en-US')+' steps';$('fpsLabel').textContent=fps.toFixed(0)+' FPS';driftPlot();
}
function populate(){
 $('lpRows').innerHTML=L.map(p=>'<tr title="'+p.name+' 残差 '+p.residual.toExponential(3)+'；'+p.iterations+' 次迭代"><td>'+p.name+'</td><td>'+p.x.toFixed(6)+'</td><td>'+p.y.toFixed(6)+'</td></tr>').join('');
 $('residualText').textContent='max |∇Ω| = '+Math.max(...L.map(p=>p.residual)).toExponential(3);
 $('muLabel').textContent=P.MU.toFixed(12);$('unitDetails').textContent='1 TU = '+P.TU.toFixed(3)+' s = '+(P.TU/86400).toFixed(6)+' d；1 VU = '+P.VU.toFixed(9)+' km/s。';
 ['x0','y0','vx0','vy0'].forEach((id,i)=>$(id).value=initial[i].toPrecision(16));$('presetDescription').textContent=presets[presetId].description;
}
// Controller: validated edits, transactional propagation, bounded history.
let accumulator=0,timeCompensation=0,lastHUD=0,frameCount=0,fpsEpoch=0,pendingInput=false,testing=false;
let changes=[{t:0,event:'init',method:settings.method,h:settings.h}],lastError=null,lastQualityWarning=0;
let flybyEntry=null,flybyExit=null;
function notice(message,error=false){$('eventBox').textContent=message;$('eventBox').classList.toggle('error',error);}
function setPaused(value){paused=value;accumulator=0;$('play').textContent=paused?'▶ 运行':'Ⅱ 暂停';$('runState').textContent=paused?'已暂停':'计算中';$('runDot').classList.toggle('paused',paused);}
function clearPending(){pendingInput=false;$('apply').classList.remove('pending');$('apply').textContent='应用初值并重置';}
function syncFields(){['x0','y0','vx0','vy0'].forEach((id,i)=>{$(id).value=String(initial[i]);$(id).title=String(initial[i]);});}
function initSimulation(s,resetView=false){
 P.validateState(s);P.validateStep(settings.h);const c=P.jacobi(s);if(!Number.isFinite(c))throw Error('初始 C 非有限');
 initial=s.slice();state=s.slice();C0=c;time=0;steps=0;timeCompensation=0;maxDrift=0;dropped=0;sampleStride=1;lastError=null;lastQualityWarning=-Infinity;
 minMoon=Math.hypot(s[0]-P.A,s[1])*P.DU-1737.4;history=[{t:0,s:s.slice(),C:C0}];driftHistory=[{t:0,d:0}];flybyEntry=null;flybyExit=null;
 changes=[{t:0,event:'init',method:settings.method,h:settings.h}];setPaused(true);clearPending();syncFields();fieldDirty=true;
 if(resetView)selectView('global');telemetry();render();
}
function capture(){
 const C=P.jacobi(state);maxDrift=Math.max(maxDrift,Math.abs(C-C0));
 minMoon=Math.min(minMoon,Math.hypot(state[0]-P.A,state[1])*P.DU-1737.4);
 if(steps%sampleStride===0){history.push({t:time,s:state.slice(),C});if(history.length>16000){const before=history.length;history=history.filter((_,i)=>i%2===0);dropped+=before-history.length;sampleStride*=2;}}
 if(steps%10===0||steps<10){driftHistory.push({t:time,d:C-C0});if(driftHistory.length>700)driftHistory.shift();}
}
function liveFlyby(before,after,oldTime,h){
 if(presetId!=='flyby'||flybyExit)return;
 const r0=Math.hypot(before[0]-P.A,before[1]),r1=Math.hypot(after[0]-P.A,after[1]),r=.18;
 if((!flybyEntry&&r0>=r&&r1<r)||(flybyEntry&&r0<r&&r1>=r)){
  const f=(r-r0)/(r1-r0),s=before.map((v,i)=>v+f*(after[i]-v)),ev={t:oldTime+f*h,speed:Math.hypot(...P.canonical(s).slice(2))*P.VU};
  if(!flybyEntry){flybyEntry=ev;notice('进入 r月 = 0.18 DU；质心惯性速率 '+ev.speed.toFixed(5)+' km/s。');}
  else{flybyExit=ev;notice('同月距出/入：惯性速率变化 '+(ev.speed-flybyEntry.speed).toFixed(5)+' km/s。非推进 Δv；插值定位过界事件。');}
 }
}
function advanceOne(){
 if(testing)return false;
 try{
  const old=state,oldTime=time,z=P.guardedStep(state,settings.h,settings.method);
  const c=P.jacobi(z);if(!Number.isFinite(c))throw new P.SafetyError('NONFINITE_C','Jacobi 值非有限；未提交。');
  // All checks succeeded; only here can state/time/history advance.
  state=z;const adjusted=settings.h-timeCompensation,next=time+adjusted;timeCompensation=(next-time)-adjusted;time=next;steps++;
  capture();liveFlyby(old,state,oldTime,settings.h);lastError=null;
  const rel=Math.abs(c-C0)/Math.max(1,Math.abs(C0));
  if(rel>1e-3){setPaused(true);lastError='DRIFT_LIMIT';notice('相对 Jacobi 漂移超过 10⁻³，已暂停。请从更小步长重新开始，不要只从误差状态续算。',true);return false;}
  if(rel>1e-7&&time-lastQualityWarning>.3){notice('守恒量误差已超过 10⁻⁷（归一化）。请减半步长并重新比较；轨迹看起来平滑并不能保证准确。',true);lastQualityWarning=time;}
  return true;
 }catch(e){lastError=e.code||e.name;setPaused(true);notice('保护暂停 ['+lastError+']：'+e.message,true);return false;}
}
function advanceN(n){
 if(!Number.isInteger(n)||n<0||n>200000)throw Error('advanceN expects an integer 0…200000');
 let done=0;for(;done<n;done++){if(!advanceOne())break;}telemetry();render();return done;
}
function startPause(){
 if(testing)return;if(!paused){setPaused(true);telemetry();return;}
 if(pendingInput){notice('初值尚未应用。请先“应用初值并重置”，或点击重置恢复已应用初值。',true);return;}
 try{P.validateState(state);P.validateStep(settings.h);}catch(e){notice(e.message,true);return;}
 setPaused(false);lastFrame=performance.now();notice('实时积分已启动；轨迹和 Jacobi 诊断来自每一步计算。');
}
function singleStep(){if(testing)return;if(pendingInput){notice('请先应用初值。',true);return;}setPaused(true);advanceOne();telemetry();render();}
function applyInitial(){
 if(testing)return;setPaused(true);
 try{
  const values=['x0','y0','vx0','vy0'].map(id=>{const raw=$(id).value.trim();if(!raw)throw new Error('初值不能为空；空值不会被当成 0。');return Number(raw);});
  if(values.some(x=>Math.abs(x)>100))throw new Error('交互初值要求 |x|、|y|、|vx|、|vy| ≤ 100。');
  P.validateState(values);initSimulation(values);presetId='custom';document.querySelectorAll('.preset').forEach(b=>b.classList.remove('active'));
  $('presetDescription').textContent='自定义初始状态，所有速度均相对于地月共转坐标系。改变初值会建立新的 C₀ 与新轨迹。';notice('自定义初值已应用。C₀ = '+C0.toPrecision(13)+'；尚未开始传播。');
 }catch(e){notice('拒绝初值：'+e.message,true);}
}
function reset(){if(testing)return;initSimulation(initial);notice('已回到最后应用的初值；t、轨迹与漂移统计清零。');}
function loadPreset(id){
 if(testing||!presets[id])return;const p=presets[id];presetId=id;settings.h=p.h;settings.rate=p.rate;$('dt').value=settings.h;$('rate').value=settings.rate;
 // Presets reset boundary reference as well; otherwise an old manual C can mislead.
 settings.boundaryMode='initial';$('boundaryMode').value='initial';$('boundaryValue').disabled=true;
 initSimulation(p.state);view.x=p.view[0];view.y=p.view[1];view.mode=id==='l1'||id==='l4'?'global':'custom';view.span=view.mode==='global'?Math.max(p.view[2],2.65*width/height):p.view[2];scale=width/view.span;fieldDirty=true;
 document.querySelectorAll('.preset').forEach(b=>b.classList.toggle('active',b.dataset.preset===id));$('presetDescription').textContent=p.description;
 notice('已载入 '+p.label+'。只定义初值，没有预生成轨迹。');render();
}
function changeStep(value){
 if(testing)return;setPaused(true);
 try{P.validateStep(value);settings.h=value;$('dt').value=String(value);changes.push({t:time,event:'step',h:value});notice('步长改为 '+value+' TU；C₀ 保持不变。长期精度比较请重置后使用固定步长。');telemetry();}
 catch(e){$('dt').value=settings.h;notice('拒绝步长：'+e.message,true);}
}
function selectView(id){
 view.mode=id==='global'?'global':'custom';
 if(id==='global'){view.x=.1;view.y=0;view.span=Math.max(3.2,2.65*width/height);}
 else if(id==='earth'){view.x=-P.MU;view.y=0;view.span=Math.max(.8,.6*width/height);}
 else if(id==='moon'){view.x=P.A;view.y=0;view.span=Math.max(.65,.45*width/height);}
 else{view.x=state[0];view.y=state[1];view.span=Math.min(view.span,1.1);}
 scale=width/view.span;fieldDirty=true;render();
}
function zoom(factor,px=width/2,py=height/2){
 view.mode='custom';const before=screenToWorld(px,py);view.span=Math.max(.045,Math.min(40,view.span*factor));scale=width/view.span;const after=screenToWorld(px,py);view.x+=before[0]-after[0];view.y+=before[1]-after[1];fieldDirty=true;render();
}
function saveFile(name,text,type){const url=URL.createObjectURL(new Blob([text],{type})),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function csv(){
 const meta={model:'planar circular restricted three-body',mu:P.MU,DU_km:P.DU,TU_s:P.TU,VU_kms:P.VU,C0,initial,retained_records:history.length,record_limit:16000,record_stride:sampleStride,removed_records:dropped,method_changes:changes,interpolation:'none; stored integration states only'};
 const data=history.slice();if(data[data.length-1].t!==time)data.push({t:time,s:state.slice(),C:P.jacobi(state)});
 return '# '+JSON.stringify(meta)+'\n'+'t_TU,x_DU,y_DU,vx_VU,vy_VU,C,delta_C\n'+data.map(p=>[p.t,...p.s,p.C,p.C-C0].map(v=>v.toPrecision(16)).join(',')).join('\n');
}
$('play').addEventListener('click',startPause);$('step').addEventListener('click',singleStep);$('reset').addEventListener('click',reset);$('apply').addEventListener('click',applyInitial);
document.querySelectorAll('.preset').forEach(b=>b.addEventListener('click',()=>loadPreset(b.dataset.preset)));
for(const id of ['x0','y0','vx0','vy0'])$(id).addEventListener('input',()=>{if(testing)return;setPaused(true);pendingInput=true;$('apply').classList.add('pending');$('apply').textContent='初值已修改 · 点击应用';});
$('method').addEventListener('change',()=>{if(testing)return;setPaused(true);settings.method=$('method').value;$('methodTag').textContent=settings.method.toUpperCase();changes.push({t:time,event:'method',method:settings.method});$('methodNote').textContent=settings.method==='sy4'?'解析旋转流 + Yoshida 复合。固定步长下保留辛结构，不强制修正 Jacobi 常数。':'对旋转系一阶方程作四阶段积分。短期精度高，但不保留辛结构；长期需监测漂移。';notice('已切换积分器；继续当前状态，不更改 C₀。公平比较请重置。');telemetry();});
$('dt').addEventListener('change',()=>changeStep($('dt').value.trim()?Number($('dt').value):NaN));$('halfStep').addEventListener('click',()=>changeStep(settings.h/2));$('doubleStep').addEventListener('click',()=>changeStep(settings.h*2));
$('rate').addEventListener('change',()=>{settings.rate=Number($('rate').value);accumulator=0;});
for(const [id,key]of [['zvc','zvc'],['forbidden','forbidden'],['showLP','lp'],['showVelocity','velocity']])$(id).addEventListener('change',()=>{settings[key]=$(id).checked;fieldDirty=true;render();});
$('boundaryMode').addEventListener('change',()=>{const val=$('boundaryMode').value;if(val==='manual')settings.manualC=boundaryC();settings.boundaryMode=val;$('boundaryValue').disabled=val!=='manual';fieldDirty=true;render();});
$('boundaryValue').addEventListener('change',()=>{const raw=$('boundaryValue').value.trim(),v=raw?Number(raw):NaN;if(!Number.isFinite(v)||v<-100||v>100){notice('边界 C 需要 −100 至 100 的有限值。',true);$('boundaryValue').value=settings.manualC;return;}settings.manualC=v;fieldDirty=true;render();});
$('clearTrail').addEventListener('click',()=>{history=[{t:time,s:state.slice(),C:P.jacobi(state)}];dropped=0;sampleStride=1;changes.push({t:time,event:'clear_display_history'});notice('仅清空显示与 CSV 轨迹缓存；未改变状态、时间或漂移统计。');render();});
$('exportCSV').addEventListener('click',()=>saveFile('cr3bp_trajectory.csv',csv(),'text/csv;charset=utf-8'));
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>selectView(b.dataset.view)));
$('zoomIn').addEventListener('click',()=>zoom(.8));$('zoomOut').addEventListener('click',()=>zoom(1.25));$('home').addEventListener('click',()=>selectView('global'));
canvas.addEventListener('wheel',e=>{e.preventDefault();const r=canvas.getBoundingClientRect();zoom(Math.exp(Math.max(-.4,Math.min(.4,e.deltaY*.001))),e.clientX-r.left,e.clientY-r.top);},{passive:false});
let dragging=null;
canvas.addEventListener('pointerdown',e=>{if(e.button!==0)return;dragging={x:e.clientX,y:e.clientY,vx:view.x,vy:view.y};canvas.setPointerCapture(e.pointerId);canvas.classList.add('dragging');$('hoverTip').style.display='none';});
canvas.addEventListener('pointermove',e=>{
 const r=canvas.getBoundingClientRect(),px=e.clientX-r.left,py=e.clientY-r.top;
 if(dragging){view.mode='custom';view.x=dragging.vx-(e.clientX-dragging.x)/scale;view.y=dragging.vy+(e.clientY-dragging.y)/scale;fieldDirty=true;render();return;}
 const q=screenToWorld(px,py);$('viewCoords').textContent='x '+q[0].toFixed(4)+' · y '+q[1].toFixed(4);
 const p=settings.lp?L.find(l=>{const a=worldToScreen(l.x,l.y);return Math.hypot(a[0]-px,a[1]-py)<15}):null;
 if(p){const t=$('hoverTip');t.textContent=p.name+'  ('+p.x.toFixed(9)+', '+p.y.toFixed(9)+')\nC = '+p.C.toFixed(11)+'\n|∇Ω| = '+p.residual.toExponential(3)+' · '+p.iterations+' iterations';t.style.left=Math.max(8,Math.min(width-285,px+14))+'px';t.style.top=Math.max(8,Math.min(height-95,py+14))+'px';t.style.display='block';}else $('hoverTip').style.display='none';
});
function endDrag(){dragging=null;canvas.classList.remove('dragging');}
canvas.addEventListener('pointerup',endDrag);canvas.addEventListener('pointercancel',endDrag);canvas.addEventListener('lostpointercapture',endDrag);canvas.addEventListener('pointerleave',()=>{$('hoverTip').style.display='none';});
function openDialog(id){setPaused(true);$(id).showModal();telemetry();}
$('methodOpen').addEventListener('click',()=>openDialog('methodsDialog'));$('methodOpenMobile').addEventListener('click',()=>openDialog('methodsDialog'));$('testOpen').addEventListener('click',()=>openDialog('testsDialog'));
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>$(b.dataset.close).close()));
document.querySelectorAll('.mobile-tabs [data-tab]').forEach(b=>b.addEventListener('click',()=>{document.body.dataset.tab=b.dataset.tab;document.querySelectorAll('.mobile-tabs button').forEach(x=>x.classList.toggle('active',x===b));requestAnimationFrame(()=>{resize();render();telemetry();});}));
document.addEventListener('keydown',e=>{if(e.target.closest('input,select,textarea,button')||document.querySelector('dialog[open]')||testing||e.ctrlKey||e.metaKey||e.altKey)return;
 if(e.code==='Space'){e.preventDefault();startPause();}else if(e.code==='KeyN')singleStep();else if(e.code==='KeyR')reset();else if(e.code==='KeyF')selectView('global');});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&!paused){setPaused(true);notice('页面已进入后台，自动暂停；回到页面后手动继续。');}});
function frame(now){
 const elapsed=lastFrame?Math.min(.1,(now-lastFrame)/1000):0;lastFrame=now;
 if(!paused&&!testing){accumulator=Math.min(accumulator+elapsed*settings.rate,.15*settings.rate);let budget=0,start=performance.now();
  while(accumulator+1e-14>=settings.h&&budget<1500&&performance.now()-start<9){if(!advanceOne())break;accumulator-=settings.h;budget++;}
 }
 frameCount++;if(!fpsEpoch)fpsEpoch=now;if(now-fpsEpoch>=700){fps=frameCount*1000/(now-fpsEpoch);fpsEpoch=now;frameCount=0;}
 if(!paused||fieldDirty)render();if(now-lastHUD>100){telemetry();lastHUD=now;}requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
let lastTestReport=null;
function progressTest(e){
 let tr=document.getElementById('test-'+e.id);
 if(!tr){tr=document.createElement('tr');tr.id='test-'+e.id;for(let i=0;i<3;i++)tr.appendChild(document.createElement('td'));$('testRows').appendChild(tr);}
 tr.children[0].textContent=e.status;tr.children[0].className='test-status '+e.status;tr.children[1].textContent=e.name;tr.children[2].textContent=e.display||'正在计算…';
 $('testProgress').style.width=100*(e.index+(e.status==='RUNNING'?0:1))/e.total+'%';
 $('testSummary').textContent='RUNNING · '+(e.index+1)+' / '+e.total;
}
async function runSelfTests(){
 if(testing)return lastTestReport;setPaused(true);testing=true;$('runTests').disabled=true;$('downloadTests').disabled=true;$('testRows').textContent='';
 const before={s:state.slice(),time,C0,steps};
 try{
  lastTestReport=await CRTests.run(progressTest,{contours:()=>window.Lab.contourDiagnostics()});
  const unchanged=time===before.time&&steps===before.steps&&C0===before.C0&&P.normDiff(state,before.s)===0;
  lastTestReport.simulationStateUnchanged=unchanged;if(!unchanged){lastTestReport.pass=false;lastTestReport.statePreservationFailure=true;}
  $('testSummary').textContent=(lastTestReport.pass?'PASS':'FAIL')+' · '+lastTestReport.passed+'/'+lastTestReport.total+' · '+(lastTestReport.durationMs/1000).toFixed(2)+' s';
  $('testSummary').className='test-summary '+(lastTestReport.pass?'mint':'warn');$('downloadTests').disabled=false;
  notice('数值自检：'+lastTestReport.passed+'/'+lastTestReport.total+' 通过；当前仿真状态'+(unchanged?'未改变。':'发生改变，验证失败。'),!lastTestReport.pass);
  return lastTestReport;
 }catch(e){$('testSummary').textContent='FAIL · '+String(e);notice('测试框架异常：'+String(e),true);throw e;}
 finally{testing=false;$('runTests').disabled=false;telemetry();}
}
$('runTests').addEventListener('click',()=>runSelfTests().catch(e=>console.error(e)));
$('downloadTests').addEventListener('click',()=>{if(lastTestReport)saveFile('cr3bp_selftest.json',JSON.stringify(lastTestReport,null,2),'application/json');});


populate();syncFields();resize();telemetry();render();new ResizeObserver(()=>{resize();render();telemetry()}).observe($('viewport'));
// Public, read-only snapshots support reproducible browser verification.
window.Lab={runSelfTests,getTestReport:()=>lastTestReport,physics:P,lagrange:L,getSnapshot:()=>({state:state.slice(),initial:initial.slice(),time,C0,steps,paused,method:settings.method,h:settings.h,rate:settings.rate,maxDrift,minMoon,historyLength:history.length,dropped,sampleStride,view:{...view},grid:{...gridInfo},boundaryC:boundaryC(),preset:presetId}),render,screenToWorld,worldToScreen,contourSegments,advanceN,loadPreset,pause:()=>setPaused(true),csv,getError:()=>lastError,getChanges:()=>changes.slice(),contourDiagnostics:()=>({count:segments.length,maxEndpointResidual:segments.reduce((m,seg)=>Math.max(m,...seg.map(a=>{const q=screenToWorld(...a);return Math.abs(2*P.omega(...q)-boundaryC())})),0)})};
})();
