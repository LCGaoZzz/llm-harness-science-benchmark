/* Executable validation, no precomputed trajectories and no embedded PASS.
   Each case reports its actual measured quantity and a declared tolerance. */
(function(root){
'use strict';const P=typeof CR3BP!=='undefined'?CR3BP:require('./core.js');
const fmt=v=>typeof v==='number'?v.toExponential(4):String(v);
function result(pass,metrics,criterion,display){return {pass,metrics,criterion,display};}
function definitions(hooks={}){
 const cases=[],add=(id,name,run)=>cases.push({id,name,run});
 for(const name of ['L1','L2','L3','L4','L5'])add('root_'+name,name+' 平衡点残差',()=>{
  const p=P.lagrangePoints().find(x=>x.name===name);
  return result(p.residual<1e-11,{...p},'norm(∇Ω) < 1e-11',fmt(p.residual)+' < 1e-11; '+p.iterations+' iterations');
 });
 add('triangular','三角点与解析几何一致',()=>{const p=P.lagrangePoints(),e=Math.max(...p.slice(3).map(a=>Math.hypot(a.x-(.5-P.MU),Math.abs(a.y)-Math.sqrt(3)/2)));return result(e<1e-12,{error:e},'position error < 1e-12',fmt(e)+' < 1e-12');});
 add('units','单位与 n=1 归一化闭合',()=>{const e=Math.abs((P.GM_E+P.GM_M)*P.TU**2/P.DU**3-1),e2=Math.abs(P.VU*P.TU-P.DU)/P.DU;return result(e<1e-14&&e2<1e-14,{normalization:e,velocityUnitError:e2,mu:P.MU,TU_s:P.TU},'both residuals < 1e-14','n² residual '+fmt(e)+'; VU residual '+fmt(e2));});
 add('gradient','有效势的独立差分梯度',()=>{const x=.37,y=.53,e=1e-6,g=P.gradient(x,y),fd=[(P.omega(x+e,y)-P.omega(x-e,y))/(2*e),(P.omega(x,y+e)-P.omega(x,y-e))/(2*e)],err=P.normDiff(g,fd);return result(err<1e-8,{error:err,epsilon:e},'gradient norm error < 1e-8',fmt(err)+' < 1e-8');});
 add('Cdot','Jacobi 导数为零',()=>{let e=0;for(const s of [[.3,.5,.2,-.1],[.7,.3,-.4,.2],[-.4,.8,.3,.3]]){const g=P.gradient(s[0],s[1]),f=P.rhs(s);e=Math.max(e,Math.abs(2*g[0]*s[2]+2*g[1]*s[3]-2*s[2]*f[2]-2*s[3]*f[3]));}return result(e<1e-13,{maxResidual:e},'max |dC/dt| < 1e-13',fmt(e)+' < 1e-13');});
 add('hamiltonian','正则动量与 C = −2H',()=>{const s=[.4,.6,.2,-.1],z=P.canonical(s),H=(z[2]**2+z[3]**2)/2+z[1]*z[2]-z[0]*z[3]-P.A/Math.hypot(z[0]+P.MU,z[1])-P.MU/Math.hypot(z[0]-P.A,z[1]),e=Math.abs(P.jacobi(s)+2*H),r=P.normDiff(s,P.velocity(z));return result(e<1e-13&&r<1e-14,{identity:e,roundtrip:r},'|C+2H| < 1e-13; canonical roundtrip < 1e-14','C+2H: '+fmt(e)+'; roundtrip '+fmt(r));});
 for(const method of ['rk4','sy4'])add('convergence_'+method,method.toUpperCase()+' 步长收敛阶',()=>{const r=P.convergence(method,[.5,.7,.1,-.1],2,.01);return result(r.d2>1e-14&&r.order>3.5&&r.order<4.5,r,'3.5 < log2(||u_h−u_h/2|| / ||u_h/2−u_h/4||) < 4.5','p = '+r.order.toFixed(5)+'; h=.01, T=2; d₁='+fmt(r.d1)+'; d₂='+fmt(r.d2));});
 for(const method of ['rk4','sy4'])add('conservation_'+method,method.toUpperCase()+' 长时守恒量',()=>{const r=P.integrate(P.presets().earth.state,.001,100000,method),threshold=method==='rk4'?1e-6:1e-7;return result(r.maxDrift<threshold,{...r,threshold},'Earth preset, T=100, h=.001; max|ΔC| < '+threshold,'T=100; N=100000; max|ΔC|='+fmt(r.maxDrift)+' < '+fmt(threshold));});
 add('reversible','SY4 时间可逆性',()=>{const s=[.4,.6,.2,-.1],forward=P.integrate(s,.002,500,'sy4').state,back=P.integrate(forward,-.002,500,'sy4').state,e=P.normDiff(s,back);return result(e<1e-9,{error:e,h:.002,stepsEachWay:500},'forward/back norm < 1e-9',fmt(e)+' < 1e-9; 500 + 500 steps');});
 add('symplectic','SY4 正则坐标辛性',()=>{const e=P.symplecticDefect();return result(e<1e-7,{maxDefect:e,finiteDifferenceEpsilon:1e-6},'max|DΦᵀ J DΦ−J| < 1e-7','max defect = '+fmt(e)+'; FD ε=1e-6');});
 add('L4_bounded','L4 扰动有界性',()=>{const p=P.presets().l4,L=P.lagrangePoints()[3];let s=p.state.slice(),maxD=0,maxC=0,C=P.jacobi(s);for(let i=0;i<50000;i++){s=P.sy4(s,.002);maxD=Math.max(maxD,Math.hypot(s[0]-L.x,s[1]-L.y));maxC=Math.max(maxC,Math.abs(P.jacobi(s)-C));}return result(maxD<.2&&maxC<1e-8,{maxDistance:maxD,maxDrift:maxC,T:100,h:.002},'T=100; max distance from L4 < .2 DU, max|ΔC| < 1e-8','max distance='+fmt(maxD)+' DU; max|ΔC|='+fmt(maxC));});
 add('L1_unstable','L1 微扰增长',()=>{const s=P.presets().l1.state,z=P.integrate(s,.0005,8000,'sy4').state,L=P.lagrangePoints()[0],d=Math.hypot(z[0]-L.x,z[1]-L.y);return result(d>.1&&d<10,{distance:d,initialOffset:.0001,T:4},'T=4; .1 < distance from L1 < 10 DU','10⁻⁴ DU → '+fmt(d)+' DU at T=4');});
 add('flyby','近月飞越与参考系',()=>{const r=P.flybyMetrics();return result(r.minR>P.RM&&r.minR<.08&&r.entry!==null&&r.exit!==null&&r.deltaInertialSpeed>0&&r.maxDrift<1e-7,r,'r_min > lunar radius, < .08 DU; matched r=.18 DU speed gain >0; |ΔC|<1e-7','min altitude='+r.minAltitudeKm.toFixed(2)+' km; Δ|vᴵ|='+(r.deltaInertialSpeed*P.VU).toFixed(6)+' km/s');});
 add('finite_guard','NaN / Infinity 防护',()=>{const rejected=[];for(const [i,s] of [[0,[NaN,1,0,0]],[1,[.5,.5,Infinity,0]],[2,[.5,-Infinity,0,0]]])for(const m of ['rk4','sy4']){try{P.guardedStep(s,.001,m)}catch(e){if(e.code==='NONFINITE')rejected.push(i+':'+m);}}return result(rejected.length===6,{rejected},'6/6 invalid inputs rejected before commit',rejected.length+'/6 rejected');});
 add('steps_guard','非法与近场步长防护',()=>{let rejected=0;for(const h of [0,-.001,NaN,Infinity,.051])try{P.guardedStep([.5,.7,0,0],h)}catch(e){if(e.code==='BAD_STEP')rejected++;}try{P.guardedStep([-P.MU+.02,0,0,5],.01)}catch(e){if(e.code==='STEP_TOO_LARGE')rejected++;}return result(rejected===6,{rejected},'6/6 invalid or unresolved steps rejected',rejected+'/6 rejected');});
 add('surfaces','奇点与天体表面防护',()=>{let rejected=0;for(const s of [[-P.MU,0,0,0],[P.A,0,0,0],[-P.MU+P.RE*.9,0,0,0],[P.A,P.RM*.5,0,0]])try{P.guardedStep(s,.001)}catch(e){if(/SURFACE/.test(e.code))rejected++;}const d=P.segmentDistance(-P.MU-.1,0,-P.MU+.1,0,-P.MU,0);return result(rejected===4&&d<1e-14,{rejected,crossingDistance:d},'4/4 body states rejected; crossing distance <1e-14',rejected+'/4 rejected; segment d='+fmt(d));});
 add('transaction','成功/失败均不修改输入',()=>{const s=P.presets().earth.state,copy=s.slice();P.guardedStep(s,.0005);let thrown=false;try{P.guardedStep(s,.05)}catch(e){thrown=true;}let badN=false;try{P.integrate(s,.001,Infinity)}catch(e){badN=true;}const e=P.normDiff(s,copy);return result(e===0&&thrown&&badN,{inputChange:e,largeStepRejected:thrown,infiniteLoopRejected:badN},'exact unchanged input; step and infinite count rejected','input change '+e+'; invalid count rejected='+badN);});
 add('zvc_sign','禁止区方向与零速度根',()=>{const L=P.lagrangePoints(),C=L[0].C,f=x=>2*P.omega(x,.3)-C;let a=.01,b=2,found=null;for(let x=a;x<b;x+=.01){if(f(x)*f(x+.01)<0){found=P.bisect(f,x,x+.01);break;}}const e=found?Math.abs(f(found.x)):Infinity,forbidden=2*P.omega(L[3].x,L[3].y)-C,allowed=2*P.omega(-P.MU+.1,0)-C;return result(e<1e-10&&forbidden<0&&allowed>0,{rootResidual:e,atL4:forbidden,nearEarth:allowed},'root <1e-10; F(L4)<0; F(nearEarth)>0','root residual '+fmt(e)+'; sign '+fmt(forbidden)+' / '+fmt(allowed));});
 if(hooks.contours)add('render_contour','当前画面边交点残差',()=>{const r=hooks.contours();return result(r.count===0||r.maxEndpointResidual<1e-4,r,'sampled contour edge roots < 1e-4; no-curve case is valid',r.count+' segments; max residual='+fmt(r.maxEndpointResidual));});
 return cases;
}
async function run(onProgress=()=>{},hooks={}){
 const cases=definitions(hooks),started=performance.now(),results=[];
 for(let i=0;i<cases.length;i++){
  const c=cases[i];onProgress({index:i,total:cases.length,id:c.id,name:c.name,status:'RUNNING'});
  await new Promise(resolve=>setTimeout(resolve,0));const start=performance.now();let r;
  try{r=c.run();if(typeof r.pass!=='boolean')throw new Error('TEST_CONTRACT');}catch(e){r={pass:false,metrics:{error:String(e)},criterion:'no unhandled exception',display:String(e)};}
  const item={id:c.id,name:c.name,status:r.pass?'PASS':'FAIL',...r,durationMs:performance.now()-start};results.push(item);onProgress({index:i,total:cases.length,...item});
 }
 const pass=results.every(r=>r.pass);
 return {schema:'cr3bp-selftest/1',generatedAt:new Date().toISOString(),userAgent:typeof navigator!=='undefined'?navigator.userAgent:'Node '+process.version,constants:{mu:P.MU,DU:P.DU,TU:P.TU,VU:P.VU},total:results.length,passed:results.filter(r=>r.pass).length,failed:results.filter(r=>!r.pass).length,pass,durationMs:performance.now()-started,results};
}
const API={definitions,run};if(typeof module!=='undefined'&&module.exports)module.exports=API;root.CRTests=API;
})(typeof globalThis!=='undefined'?globalThis:this);
