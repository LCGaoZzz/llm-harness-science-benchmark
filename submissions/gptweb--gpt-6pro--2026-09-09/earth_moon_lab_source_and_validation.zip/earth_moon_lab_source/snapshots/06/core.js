/* CR3BP numerical kernel. All state vectors are [x, y, vx, vy] in the
   barycentric, counterclockwise co-rotating frame. No force softening.
   Constants: JPL NAIF gm_de440.tpc, BODY399_GM and BODY301_GM.
   The fixed 384400 km separation is a model choice, not an ephemeris. */
(function(root){
'use strict';
const GM_E=398600.43550702266, GM_M=4902.80011845755, DU=384400;
const MU=GM_M/(GM_E+GM_M), A=1-MU;
const TU=Math.sqrt(DU**3/(GM_E+GM_M)), VU=DU/TU;
const RE=6371/DU, RM=1737.4/DU;
function gravity(x,y) {
 const u=x+MU, v=x-A, re=Math.hypot(u,y), rm=Math.hypot(v,y);
 if(!Number.isFinite(re+rm)||re<1e-12||rm<1e-12) throw new Error('SINGULAR: 非有限坐标或天体中心奇点');
 const a=A/(re*re*re), b=MU/(rm*rm*rm);
 return [-a*u-b*v, -(a+b)*y];
}
function rhs(s){const [x,y,vx,vy]=s, g=gravity(x,y); return [vx,vy,2*vy+x+g[0],-2*vx+y+g[1]];}
function omega(x,y){const re=Math.hypot(x+MU,y),rm=Math.hypot(x-A,y);return .5*(x*x+y*y)+A/re+MU/rm;}
function jacobi(s){return 2*omega(s[0],s[1])-s[2]*s[2]-s[3]*s[3];}
function gradient(x,y){const g=gravity(x,y);return [x+g[0],y+g[1]];}
function hessian(x,y){
 const u=x+MU,v=x-A,re=Math.hypot(u,y),rm=Math.hypot(v,y);
 const a=A/re**3,b=MU/rm**3,c=3*A/re**5,d=3*MU/rm**5;
 return [1-a-b+c*u*u+d*v*v,(c*u+d*v)*y,1-a-b+(c+d)*y*y];
}
// Bracketed scalar solve never crosses a primary; triangular points use
// genuinely two-dimensional Newton iterations, not tabulated coordinates.
function bisect(f,lo,hi){
 let a=f(lo),b=f(hi);if(a*b>=0)throw new Error('ROOT_BRACKET');
 let mid=(lo+hi)/2,iterations=0;
 for(;iterations<100;iterations++){
  mid=(lo+hi)/2;const v=f(mid);
  if(Math.abs(v)<2e-15 || Math.abs(hi-lo)<5e-16)break;
  if(a*v<=0){hi=mid;b=v;}else{lo=mid;a=v;}
 }
 return {x:mid,iterations:iterations+1};
}
function lagrangePoints(){
 const f=x=>gradient(x,0)[0],eps=1e-7;
 const brackets=[[-MU+eps,A-eps],[A+eps,3],[-3,-MU-eps]];
 const points=brackets.map((b,i)=>{const z=bisect(f,...b);return {name:'L'+(i+1),x:z.x,y:0,iterations:z.iterations};});
 for(const sign of [1,-1]){
  let x=.43,y=sign*.78,it=0;
  for(;it<30;it++){
   const [gx,gy]=gradient(x,y),[xx,xy,yy]=hessian(x,y),det=xx*yy-xy*xy;
   if(Math.hypot(gx,gy)<1e-15)break;
   if(Math.abs(det)<1e-16)throw new Error('ROOT_JACOBIAN');
   x-=(yy*gx-xy*gy)/det;y-=(-xy*gx+xx*gy)/det;
  }
  points.push({name:sign>0?'L4':'L5',x,y,iterations:it+1});
 }
 return points.map(p=>({...p,residual:Math.hypot(...gradient(p.x,p.y)),C:2*omega(p.x,p.y)}));
}
function rk4(s,h){
 const k1=rhs(s),k2=rhs(s.map((v,i)=>v+h*.5*k1[i]));
 const k3=rhs(s.map((v,i)=>v+h*.5*k2[i])),k4=rhs(s.map((v,i)=>v+h*k3[i]));
 return s.map((v,i)=>v+h/6*(k1[i]+2*k2[i]+2*k3[i]+k4[i]));
}
/* H(q,p) = |p|²/2 + y*px - x*py - A/rE - MU/rM, C=-2H.
   px=vx-y; py=vy+x. Split H=H_A+H_B.
   A-flow is exact: q'=R(-h)(q+h*p), p'=R(-h)p.
   B-flow is exact: p'=p+h*g(q).
   S2(h)=B(h/2) A(h) B(h/2).
   S4=S2(w1*h) S2(w0*h) S2(w1*h), Yoshida triple jump.
   Fixed step; negative composition substeps are intrinsic, not time reversal UI.
   NOT velocity Verlet applied to a velocity-dependent force. */
const W1=1/(2-Math.cbrt(2)),W0=-Math.cbrt(2)/(2-Math.cbrt(2));
function canonical(s){return [s[0],s[1],s[2]-s[1],s[3]+s[0]];}
function velocity(z){return [z[0],z[1],z[2]+z[1],z[3]-z[0]];}
function sy4(s,h){
 let [x,y,px,py]=canonical(s);
 for(const w of [W1,W0,W1]){
  const d=w*h;let g=gravity(x,y);px+=d*.5*g[0];py+=d*.5*g[1];
  const c=Math.cos(d),sn=Math.sin(d),qx=x+d*px,qy=y+d*py;
  x=c*qx+sn*qy;y=-sn*qx+c*qy;
  const ax=c*px+sn*py;py=-sn*px+c*py;px=ax;
  g=gravity(x,y);px+=d*.5*g[0];py+=d*.5*g[1];
 }
 return velocity([x,y,px,py]);
}
function symplecticDefect(s=[.4,.6,.2,-.1],h=.01){
 // Central finite-difference Jacobian in CANONICAL (q,p), not (q,v).
 const z=canonical(s),e=1e-6,M=Array.from({length:4},()=>Array(4).fill(0));
 for(let j=0;j<4;j++){
  const a=z.slice(),b=z.slice();a[j]+=e;b[j]-=e;
  const f=canonical(sy4(velocity(a),h)),g=canonical(sy4(velocity(b),h));
  for(let i=0;i<4;i++)M[i][j]=(f[i]-g[i])/(2*e);
 }
 const J=[[0,0,1,0],[0,0,0,1],[-1,0,0,0],[0,-1,0,0]];let err=0;
 for(let i=0;i<4;i++)for(let j=0;j<4;j++){
  let v=0;for(let k=0;k<4;k++)for(let l=0;l<4;l++)v+=M[k][i]*J[k][l]*M[l][j];
  err=Math.max(err,Math.abs(v-J[i][j]));
 }
 return err;
}
function integrate(s,h,n,method='rk4'){
 const fn=method==='rk4'?rk4:sy4;let z=s.slice(),maxDrift=0,C0=jacobi(s);
 for(let i=0;i<n;i++){z=fn(z,h);maxDrift=Math.max(maxDrift,Math.abs(jacobi(z)-C0));}
 return {state:z,maxDrift,C0,steps:n,time:h*n};
}
function normDiff(a,b){return Math.hypot(...a.map((v,i)=>v-b[i]));}
function convergence(method,s=[.5,.7,.1,-.1],T=2,h=.02){
 const run=[h,h/2,h/4].map(dt=>integrate(s,dt,Math.round(T/dt),method));
 const d1=normDiff(run[0].state,run[1].state),d2=normDiff(run[1].state,run[2].state);
 return {method,T,h,d1,d2,ratio:d1/d2,order:Math.log2(d1/d2),drifts:run.map(r=>r.maxDrift)};
}
function presets(){
 const L=lagrangePoints();
 return {
  l4:{label:'L4 扰动',tag:'准周期运动',description:'在数值求得的 L4 附近加入位置与速度扰动。观察旋转系中的有界振荡；稳定不等于轨迹闭合。',state:[L[3].x+.012,L[3].y-.015,0,.018],h:.002,rate:1.5,view:[.05,0,3.2]},
  l1:{label:'L1 不稳定运动',tag:'敏感性实验',description:'L1 向地球侧偏移 10⁻⁴ DU，旋转系初速为零。偏离会增长；这不是经微分校正的周期轨道。',state:[L[0].x-.0001,0,0,0],h:.0005,rate:.5,view:[.1,0,3.2]},
  earth:{label:'绕地轨道',tag:'受月球摄动',description:'地心半径 0.18 DU，以二体圆轨道速度初始化，并扣除坐标系旋转速度。它在完整模型中不是精确圆轨道。',state:[-MU+.18,0,0,Math.sqrt(A/.18)-.18],h:.0005,rate:.15,view:[-MU,0,.8]},
  flyby:{label:'月球引力辅助',tag:'近月飞越',description:'从月球后侧飞越；旋转系速率变化不等于能量增益。对照同一月距处的质心惯性速率，并监测 Jacobi 常数。',state:[A-.25,-.02,.6,.15],h:.0005,rate:.08,view:[.85,0,1.5]}
 };
}
function flybyMetrics(method='sy4',h=.0005,T=1.5){
 let s=presets().flyby.state.slice(),minR=Infinity,entry=null,exit=null,maxDrift=0;
 const C0=jacobi(s),fn=method==='rk4'?rk4:sy4, radius=.18;
 for(let i=0;i<Math.round(T/h);i++){
  const before=s,prevR=Math.hypot(s[0]-A,s[1]);s=fn(s,h);
  const r=Math.hypot(s[0]-A,s[1]);minR=Math.min(minR,r);maxDrift=Math.max(maxDrift,Math.abs(jacobi(s)-C0));
  // Linear interpolation only for diagnostic crossing events, never trajectory propagation.
  if((!entry&&prevR>=radius&&r<radius)||(entry&&!exit&&prevR<radius&&r>=radius)){
   const f=(radius-prevR)/(r-prevR),z=before.map((v,j)=>v+f*(s[j]-v));
   const ev={t:(i+f)*h,state:z,speed:Math.hypot(...canonical(z).slice(2))};
   if(!entry)entry=ev;else exit=ev;
  }
 }
 return {method,h,T,minR,minAltitudeKm:minR*DU-1737.4,entry,exit,deltaInertialSpeed:entry&&exit?exit.speed-entry.speed:null,maxDrift};
}
class SafetyError extends Error{constructor(code,message){super(message);this.name='SafetyError';this.code=code;}}
function validateState(s){
 if(!Array.isArray(s)||s.length!==4||!s.every(Number.isFinite))throw new SafetyError('NONFINITE','状态含 NaN / Infinity；未提交此步。');
 if(s.some(v=>Math.abs(v)>1e6))throw new SafetyError('DOMAIN','状态超过数值域；请重设初值。');
 if(Math.hypot(s[0]+MU,s[1])<=RE)throw new SafetyError('EARTH_SURFACE','状态进入地球表面保护区。');
 if(Math.hypot(s[0]-A,s[1])<=RM)throw new SafetyError('MOON_SURFACE','状态进入月球表面保护区。');
 return true;
}
function validateStep(h){if(!Number.isFinite(h)||h<1e-6||h>.05)throw new SafetyError('BAD_STEP','步长必须在 10⁻⁶ 至 0.05 TU 之间。');}
function segmentDistance(ax,ay,bx,by,cx,cy){
 const dx=bx-ax,dy=by-ay,q=dx*dx+dy*dy,t=q===0?0:Math.max(0,Math.min(1,((cx-ax)*dx+(cy-ay)*dy)/q));
 return Math.hypot(ax+t*dx-cx,ay+t*dy-cy);
}
function guardedStep(s,h,method='sy4'){
 validateState(s);validateStep(h);
 if(!['sy4','rk4'].includes(method))throw new SafetyError('METHOD','未知积分器。');
 const re=Math.hypot(s[0]+MU,s[1]),rm=Math.hypot(s[0]-A,s[1]);
 const frequency=Math.max(Math.sqrt(A/re**3),Math.sqrt(MU/rm**3));
 const travel=Math.hypot(s[2],s[3])/Math.min(re,rm);
 const limit=.08/Math.max(frequency,travel,1);
 if(h>limit)throw new SafetyError('STEP_TOO_LARGE','近场步长过大：建议 h ≤ '+limit.toExponential(2)+' TU；未自动变步。');
 const z=method==='rk4'?rk4(s,h):sy4(s,h);
 validateState(z);
 if(segmentDistance(s[0],s[1],z[0],z[1],-MU,0)<=RE||segmentDistance(s[0],s[1],z[0],z[1],A,0)<=RM)
  throw new SafetyError('SURFACE_CROSSING','此步线段穿越天体保护区；保留上一步。非精确碰撞定时。');
 return z; // Pure: caller commits state/time/history only after successful return.
}
const API={SafetyError,validateState,validateStep,guardedStep,segmentDistance,presets,flybyMetrics,sy4,canonical,velocity,symplecticDefect,W1,W0,rk4,integrate,normDiff,convergence,bisect,lagrangePoints,GM_E,GM_M,DU,MU,A,TU,VU,RE,RM,gravity,rhs,omega,jacobi,gradient,hessian};
if(typeof module!=='undefined'&&module.exports) module.exports=API;root.CR3BP=API;
})(typeof globalThis!=='undefined'?globalThis:this);
