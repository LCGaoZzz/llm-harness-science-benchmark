from pathlib import Path
p=Path(__file__).parent
s=(p/'shell.html').read_text()
for token,name in [('/*__CORE__*/','core.js'),('/*__TESTS__*/','tests.js'),('/*__UI__*/','ui.js')]:
 f=p/name;s=s.replace(token,f.read_text() if f.exists() else '')
(p/'earth_moon_lab.html').write_text(s)
print('Built',len(s.encode()),'bytes')
