"""Fresh browser validation of the SINGLE delivery HTML; no source-file imports.
The managed execution environment blocks file:// and localhost navigation.
We separately check HTTP delivery, then execute that exact complete body in a
fresh offline Chromium page using set_content (real DOM/JS/Canvas, not a mock).
"""
from pathlib import Path
from html.parser import HTMLParser
from urllib.request import urlopen
from playwright.sync_api import sync_playwright
import json,hashlib,shutil,math,datetime,sys
P=Path(__file__).resolve().parent; V=P/'validation'; V.mkdir(exist_ok=True)
HTML=P/'earth_moon_lab.html'; raw=HTML.read_bytes(); html=raw.decode('utf-8')
class Audit(HTMLParser):
 def __init__(self):super().__init__();self.dependencies=[];self.script_count=0
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=='script':
   self.script_count+=1
   if a.get('src'):self.dependencies.append(a['src'])
  if tag=='link' and a.get('rel') in ('stylesheet','preload','modulepreload'):self.dependencies.append(a.get('href'))
  if tag in ('img','iframe','audio','video','source') and a.get('src') and not a['src'].startswith('data:'):self.dependencies.append(a['src'])
audit=Audit();audit.feed(html)
assert not audit.dependencies and '/*__CORE__*/' not in html and '/*__TESTS__*/' not in html and '/*__UI__*/' not in html
assert '1.8*vy+x+g[0]' not in html  # Deliberate mutant must NEVER enter final delivery.
clean=P/'clean_delivery';clean.mkdir(exist_ok=True);shutil.copy2(HTML,clean/HTML.name)
assert [x.name for x in clean.iterdir()]==[HTML.name]
http={}
try:
 with urlopen('http://127.0.0.1:8765/earth_moon_lab.html',timeout=8) as r:
  body=r.read();http={'status':r.status,'content_type':r.headers.get('Content-Type'),'sha256':hashlib.sha256(body).hexdigest(),'identical_to_file':body==raw}
except Exception as e:
 http={'error':str(e)};body=raw
checks=[];errors=[];console=[];requests=[]
def record(name,ok,detail=None):
 checks.append({'name':name,'pass':bool(ok),'detail':detail})
 if not ok:print('FAIL',name,detail)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 navigation=[]
 for url in ['file://'+str(clean/HTML.name),'http://127.0.0.1:8765/earth_moon_lab.html']:
  pp=b.new_page()
  try:
   rr=pp.goto(url,wait_until='load',timeout=8000);navigation.append({'url':url,'success':True,'http_status':rr.status if rr else None})
  except Exception as e:navigation.append({'url':url,'success':False,'error':str(e)})
  pp.close()
 # No external resources can load in this offline browser context.
 context=b.new_context(viewport={'width':1560,'height':1000},offline=True,accept_downloads=True)
 page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.on('console',lambda m:console.append({'type':m.type,'text':m.text}));page.on('request',lambda r:requests.append(r.url))
 page.set_content(body.decode('utf-8'),wait_until='load');page.wait_for_timeout(180)
 snap=lambda:page.evaluate('Lab.getSnapshot()')
 first=snap();record('fresh default is paused and has only initial state',first['paused'] and first['steps']==0 and first['time']==0 and first['historyLength']==1,first)
 record('no canned test results before execution','NOT RUN' in page.inner_text('#testSummary'))
 page.click('#step');record('single-step advances exactly h',snap()['steps']==1 and snap()['time']==snap()['h'])
 page.click('#reset');record('reset restores full initial state',snap()['state']==first['state'] and snap()['time']==0 and snap()['historyLength']==1)
 page.click('#play');page.wait_for_timeout(300);page.click('#play');paused=snap();page.wait_for_timeout(90)
 record('live real-time propagation then exact pause',paused['steps']>0 and snap()['time']==paused['time'],{'steps':paused['steps'],'T':paused['time']})
 # Preserve current state during a real user-initiated selftest, download exact report.
 before=snap();page.click('#testOpen');page.click('#runTests');page.wait_for_function('Lab.getTestReport() !== null',timeout=30000)
 report=page.evaluate('Lab.getTestReport()')
 record('offline full executable suite',report['pass'] and report['passed']==25 and report['failed']==0,{'passed':report['passed'],'total':report['total'],'durationMs':report['durationMs']})
 with page.expect_download() as d:page.click('#downloadTests')
 d.value.save_as(V/'final_browser_selftest.json')
 record('exported JSON equals actual browser result',json.loads((V/'final_browser_selftest.json').read_text())==report)
 record('selftests preserve state time C0 and step counter',before['state']==snap()['state'] and before['time']==snap()['time'] and before['C0']==snap()['C0'] and before['steps']==snap()['steps'])
 page.screenshot(path=str(V/'final_selftest.png'),full_page=True)
 page.click('[data-close="testsDialog"]')
 # Final frame is obtained from a fresh live integration, never embedded into HTML.
 page.click('[data-preset="l1"]');done=page.evaluate('Lab.advanceN(12000)');page.screenshot(path=str(V/'final_desktop.png'),full_page=True)
 record('screenshot is actual 12000-step L1 integration',done==12000 and abs(snap()['time']-6)<1e-12,{'time':snap()['time'],'maxDrift':snap()['maxDrift']})
 with page.expect_download() as d:page.click('#exportCSV')
 d.value.save_as(V/'final_live_trajectory.csv')
 csv_text=(V/'final_live_trajectory.csv').read_text()
 record('trajectory export contains real initial and integrated samples',len(csv_text.splitlines())>=12002,{'lines':len(csv_text.splitlines())})
 record('no page exceptions or console errors',not errors and not [x for x in console if x['type']=='error'],{'pageErrors':errors,'console':console})
 record('no external network dependency at runtime',not requests and not audit.dependencies,{'requests':requests,'static_dependencies':audit.dependencies,'inline_script_count':audit.script_count})
 record('HTTP body is the exact standalone file',http.get('status')==200 and http.get('identical_to_file'),http)
 result={'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'browser':b.version,
         'html_sha256':hashlib.sha256(raw).hexdigest(),'html_bytes':len(raw),'http_delivery':http,
         'navigation_attempts':navigation,'execution_mode':'real Chromium, full HTML set_content in fresh offline context',
         'checks':checks,'passed':sum(c['pass'] for c in checks),'total':len(checks),'pass':all(c['pass'] for c in checks),
         'selftest_report_file':'final_browser_selftest.json','selftest_passed':report['passed'],'selftest_total':report['total'],
         'console':console,'pageErrors':errors,'requests':requests}
 (V/'r12.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('FINAL',result['passed'],'/',result['total'],'Selftest',report['passed'],'/',report['total'],'Browser',b.version);b.close()
if not result['pass']:sys.exit(1)
