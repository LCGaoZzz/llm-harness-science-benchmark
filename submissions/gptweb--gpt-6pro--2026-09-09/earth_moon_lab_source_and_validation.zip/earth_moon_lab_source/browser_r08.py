from pathlib import Path
from playwright.sync_api import sync_playwright
import json
p=Path(__file__).resolve().parent;checks=[];errors=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':960})
 page.on('pageerror',lambda e:errors.append(str(e)));page.set_content((p/'earth_moon_lab.html').read_text());page.wait_for_timeout(300)
 def check(name,ok,details=None):
  checks.append({'name':name,'pass':bool(ok),'details':details});assert ok,name
 snap=lambda:page.evaluate('Lab.getSnapshot()')
 check('initial contains only initial state',snap()['historyLength']==1)
 page.click('#step');s=snap();check('single step',s['steps']==1 and abs(s['time']-.0005)<1e-15,s)
 page.click('#play');page.wait_for_timeout(450);page.click('#play');s=snap();check('real-time propagation',s['steps']>50,s['steps']);t=s['time'];page.wait_for_timeout(200);check('pause exact time hold',snap()['time']==t)
 page.select_option('#method','rk4');check('method switch preserves state',snap()['time']==t and snap()['C0']==s['C0'])
 page.click('#halfStep');check('step halve',snap()['h']==.00025 and snap()['time']==t)
 page.click('#reset');check('reset',snap()['steps']==0 and snap()['historyLength']==1)
 page.click('[data-preset="earth"]');page.evaluate('Lab.advanceN(3000)');check('earth propagation',snap()['time']==1.5 and snap()['maxDrift']<1e-8)
 with page.expect_download() as dl:page.click('#exportCSV')
 dest=p/'validation/r08_trajectory.csv';dl.value.save_as(dest);check('CSV real rows',len(dest.read_text().splitlines())==3003)
 page.click('#zoomIn');before=snap()['view'];r=page.locator('#scene').bounding_box();page.mouse.move(r['x']+r['width']*.5,r['y']+r['height']*.5);page.mouse.down();page.mouse.move(r['x']+r['width']*.5+80,r['y']+r['height']*.5+40,steps=4);page.mouse.up();check('pan updates view',snap()['view']['x']!=before['x'])
 page.click('[data-preset="l1"]');d=page.evaluate('Lab.contourDiagnostics()');check('contour actual root residual',d['count']>100 and d['maxEndpointResidual']<1e-5,d)
 page.fill('#x0','');page.click('#apply');check('empty rejected',snap()['initial'][0]==s['initial'][0] and '不能为空' in page.inner_text('#eventBox'))
 page.screenshot(path=str(p/'validation/r08_desktop.png'),full_page=True)
 result={'checks':checks,'errors':errors,'pass':all(x['pass']for x in checks) and not errors};(p/'validation/r08.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2));b.close()
