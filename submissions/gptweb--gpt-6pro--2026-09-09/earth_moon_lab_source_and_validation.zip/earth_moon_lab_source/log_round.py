import sys,json,hashlib,shutil,pathlib,datetime
p=pathlib.Path(__file__).resolve().parent; n=int(sys.argv[1]); title=sys.argv[2]; review=sys.argv[3]; change=sys.argv[4]; result=json.load(open(sys.argv[5])); snap=p/'snapshots'/f'{n:02d}';snap.mkdir(exist_ok=True)
hashes={}
for name in ['core.js','tests.js','ui.js','shell.html','build.py','earth_moon_lab.html']:
 f=p/name
 if f.exists():
  shutil.copy(f,snap/name); hashes[name]=hashlib.sha256(f.read_bytes()).hexdigest()
entry={'round':n,'title':title,'review':review,'change':change,'validation':result,'hashes':hashes,'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
log=p/'iterations.json';data=json.load(open(log)) if log.exists() else [];data.append(entry);log.write_text(json.dumps(data,ensure_ascii=False,indent=2));print(f'Round {n}: {title} recorded')
