const c=require('./core.js');
function test(s,T,h){let z=s.slice(),minM=9,minE=9,maxL=0,C0=c.jacobi(s),maxDrift=0,near=null,entry=null,exit=null;for(let i=0;i<T/h;i++){
 z=c.rk4(z,h);let rM=Math.hypot(z[0]-c.A,z[1]),rE=Math.hypot(z[0]+c.MU,z[1]);
 if(rM<minM){minM=rM;near={time:(i+1)*h,state:z.slice()};}minE=Math.min(minE,rE);
 maxL=Math.max(maxL,Math.hypot(z[0]-(.5-c.MU),z[1]-Math.sqrt(3)/2));
 if(!entry&&rM<.18)entry={s:z.slice(),t:(i+1)*h};if(entry&&!exit&&rM>.18)exit={s:z.slice(),t:(i+1)*h};
 if(rE<c.RE||rM<c.RM)return {collision:true,minM,minE};
 maxDrift=Math.max(maxDrift,Math.abs(c.jacobi(z)-C0));
 }
 let gain=entry&&exit?Math.hypot(...c.canonical(exit.s).slice(2))-Math.hypot(...c.canonical(entry.s).slice(2)):null;
 return {minM,minE,maxL,maxDrift,state:z,near,gain,entry,exit};
}
let best=[];for(const yy of [-.1,-.06,-.04,-.02])for(const vx of [.6,.8,1.0,1.2])for(const vy of [.15,.3,.45]){
 const s=[c.A-.25,yy,vx,vy],r=test(s,1.5,.0005);
 if(!r.collision&&r.minM>.015&&r.minM<.09&&r.gain>.02)best.push({s,...r});
}best.sort((a,b)=>b.gain-a.gain);
let l4=[.5-c.MU+.012,Math.sqrt(3)/2-.015,0,.018];let earth=[-c.MU+.18,0,0,Math.sqrt(c.A/.18)-.18];let p=c.lagrangePoints();let l1=[p[0].x-.0001,0,0,0];
console.log(JSON.stringify({flyby_candidates:best.slice(0,5),l4:test(l4,100,.002),earth:test(earth,10,.0005),l1:test(l1,4,.0005)},null,2));
