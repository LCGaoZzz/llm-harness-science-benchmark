from playwright.sync_api import sync_playwright
from pathlib import Path
import json
p=Path(__file__).resolve().parent;errors=[];logs=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1560,'height':1000},device_scale_factor=1)
 page.on('pageerror',lambda e:errors.append(str(e)));page.on('console',lambda m:logs.append({'type':m.type,'text':m.text}))
 navigation=[]
 for url in [(p/'earth_moon_lab.html').as_uri(),'http://127.0.0.1:8765/earth_moon_lab.html']:
  try:
   page.goto(url,wait_until='load',timeout=5000);navigation.append({'url':url,'success':True});break
  except Exception as e: navigation.append({'url':url,'success':False,'error':str(e)})
 else:
  page.close();page=browser.new_page(viewport={'width':1560,'height':1000},device_scale_factor=1)
  errors.clear();logs.clear();page.on('pageerror',lambda e:errors.append(str(e)));page.on('console',lambda m:logs.append({'type':m.type,'text':m.text}))
  page.set_content((p/'earth_moon_lab.html').read_text(),wait_until='load')
 page.wait_for_timeout(300)
 page.screenshot(path=str(p/'validation/r07_desktop.png'),full_page=True)
 snap=page.evaluate('Lab.getSnapshot()')
 result={'browser':browser.version,'navigation':navigation,'errors':errors,'console':logs,'snapshot':snap,'pass':not errors and snap['grid']['segments']>0}
 (p/'validation/r07.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2));browser.close()
