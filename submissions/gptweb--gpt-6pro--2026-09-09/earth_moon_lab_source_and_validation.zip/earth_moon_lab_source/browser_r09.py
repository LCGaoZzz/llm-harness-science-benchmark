from pathlib import Path
from playwright.sync_api import sync_playwright
import json
p=Path(__file__).resolve().parent;errors=[];logs=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':1560,'height':1000})
 page.on('pageerror',lambda e:errors.append(str(e)));page.on('console',lambda m:logs.append({'type':m.type,'text':m.text}));page.set_content((p/'earth_moon_lab.html').read_text());page.wait_for_timeout(200)
 before=page.evaluate('Lab.getSnapshot()');page.click('#testOpen');page.click('#runTests');page.wait_for_function('Lab.getTestReport() !== null',timeout=30000)
 r=page.evaluate('Lab.getTestReport()');assert r['pass'] and r['total']==25
 with page.expect_download() as dl:page.click('#downloadTests')
 dl.value.save_as(p/'validation/browser_selftest.json');assert json.loads((p/'validation/browser_selftest.json').read_text())==r
 page.screenshot(path=str(p/'validation/r09_selftest.png'),full_page=True);page.click('[data-close="testsDialog"]');after=page.evaluate('Lab.getSnapshot()');assert before['state']==after['state'] and before['time']==after['time']
 result={'browser':b.version,'selftest':r,'download_matches':True,'state_preserved':True,'errors':errors,'console':logs,'pass':r['pass'] and not errors}
 (p/'validation/r09.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print({k:r[k]for k in ['total','passed','failed','durationMs']});b.close()
