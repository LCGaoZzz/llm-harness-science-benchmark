from pathlib import Path
from playwright.sync_api import sync_playwright
import json,math
p=Path(__file__).resolve().parent;html=(p/'earth_moon_lab.html').read_text();checks=[];errors=[];console=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1480,'height':960});page.on('pageerror',lambda e:errors.append(str(e)));page.on('console',lambda m:console.append({'type':m.type,'text':m.text}));page.set_content(html);page.wait_for_timeout(100)
 def record(name,ok,detail=None):
  checks.append({'name':name,'pass':bool(ok),'detail':detail})
  if not ok:print('FAILED',name,detail)
 snap=lambda:page.evaluate('Lab.getSnapshot()')
 for method in ['rk4','sy4']:
  page.select_option('#method',method)
  for preset,n in [('l4',15000),('l1',8000),('earth',5000),('flyby',3000)]:
   page.click('[data-preset="'+preset+'"]');done=page.evaluate('(n)=>Lab.advanceN(n)',n);s=snap();record(method+' '+preset+' guarded propagation',done==n and s['maxDrift']<1e-7,{'done':done,'T':s['time'],'maxDrift':s['maxDrift']})
   if preset=='flyby':record(method+' live flyby diagnostic','同月距' in page.inner_text('#eventBox'),page.inner_text('#eventBox'))
 page.click('[data-preset="l1"]');page.uncheck('#zvc');page.uncheck('#forbidden');page.select_option('#boundaryMode','manual');page.fill('#boundaryValue','3.5');page.locator('#boundaryValue').blur();record('hidden layers still update boundary label','3.500000000' in page.inner_text('#contourLabel'),page.inner_text('#contourLabel'));record('hidden contour no stale segments',snap()['grid']['segments']==0)
 page.check('#zvc');page.check('#forbidden');before=snap()['C0'];page.select_option('#boundaryMode','L2');record('reference C is independent',snap()['boundaryC']!=before and snap()['C0']==before)
 page.click('[data-preset="l4"]');record('L4 preset has no forbidden curve at its C0',snap()['grid']['segments']==0 and '无禁止区' in page.inner_text('#boundaryNote'))
 page.click('[data-preset="earth"]');page.evaluate('Lab.advanceN(40000)');s=snap();record('bounded history compression',s['historyLength']<=16000 and s['sampleStride']>1 and s['dropped']>0,s)
 t=s['time'];C0=s['C0'];page.click('#clearTrail');record('clear display preserves time and C0',snap()['time']==t and snap()['C0']==C0 and snap()['historyLength']==1)
 page.click('[data-preset="earth"]');page.fill('#dt','0.05');page.locator('#dt').blur();before=snap();page.click('#step');after=snap();record('unsafe step rolls back live state/time/history',after['state']==before['state'] and after['time']==before['time'] and after['historyLength']==before['historyLength'] and 'STEP_TOO_LARGE' in page.inner_text('#eventBox'))
 page.click('[data-preset="l1"]');before=snap();page.fill('#x0',str(-page.evaluate('CR3BP.MU')));page.fill('#y0','0');page.click('#apply');record('body-center input rejected',snap()['state']==before['state'] and '保护区' in page.inner_text('#eventBox'))
 page.fill('#x0','0.5');page.fill('#y0','0.7');page.fill('#vx0','0.1');page.fill('#vy0','-0.1');page.click('#apply');record('custom initial values apply atomically',snap()['state']==[.5,.7,.1,-.1] and snap()['steps']==0)
 for v in ['global','moon','earth','craft']:
  s=snap();page.click('[data-view="'+v+'"]');record(v+' view leaves physics unchanged',snap()['state']==s['state'] and snap()['time']==s['time'])
 page.click('[data-preset="l1"]');page.locator('body').click(position={'x':600,'y':30});page.keyboard.press('n');record('N keyboard step',snap()['steps']==1);page.keyboard.press('r');record('R keyboard reset',snap()['steps']==0)
 page.set_viewport_size({'width':2100,'height':900});page.click('[data-view="global"]');pts=page.evaluate('Lab.lagrange.map(l=>Lab.worldToScreen(l.x,l.y))');size=page.locator('#scene').bounding_box();record('ultrawide global view keeps all L points visible',all(0<x<size['width']and 0<y<size['height']for x,y in pts),{'points':pts,'canvas':size})
 # Deliberate equation defect in a separate page: verify genuine test failure.
 mutant=html.replace('2*vy+x+g[0]','1.8*vy+x+g[0]')
 assert mutant!=html
 mp=b.new_page();mp.set_content(mutant);mr=mp.evaluate('Lab.runSelfTests()');record('mutation test rejects incorrect Coriolis coefficient',not mr['pass'] and mr['failed']>0,{'failed':mr['failed'],'cases':[x['id']for x in mr['results']if not x['pass']]});(p/'validation/mutation_test.json').write_text(json.dumps(mr,ensure_ascii=False,indent=2));mp.close()
 # Mobile, real viewport interaction, no synthetic CSS assertions alone.
 mob=b.new_page(viewport={'width':390,'height':844},device_scale_factor=2,is_mobile=True,has_touch=True);mob.on('pageerror',lambda e:errors.append('mobile '+str(e)));mob.set_content(html);mob.wait_for_timeout(150)
 overflow=mob.evaluate('({w:innerWidth,scroll:document.documentElement.scrollWidth,h:innerHeight,scrollH:document.documentElement.scrollHeight})');record('mobile no page overflow',overflow['scroll']<=overflow['w']and overflow['scrollH']<=overflow['h'],overflow)
 mob.screenshot(path=str(p/'validation/r10_mobile_plot.png'),full_page=True)
 mob.click('.mobile-tabs [data-tab="controls"]');record('mobile controls tab visible',mob.locator('.left').is_visible() and not mob.locator('.workspace').is_visible());mob.click('[data-preset="earth"]');mob.click('#step');record('mobile single-step',mob.evaluate('Lab.getSnapshot().steps')==1)
 mob.screenshot(path=str(p/'validation/r10_mobile_controls.png'),full_page=True)
 mob.click('.mobile-tabs [data-tab="diagnostics"]');record('mobile diagnostics visible',mob.locator('.right').is_visible());mob.screenshot(path=str(p/'validation/r10_mobile_diagnostics.png'),full_page=True)
 mob.click('#testOpen');mob.click('#runTests');mob.wait_for_function('Lab.getTestReport() !== null');mrep=mob.evaluate('Lab.getTestReport()');record('mobile executable selftest',mrep['pass'],{'passed':mrep['passed'],'total':mrep['total']});mob.close()
 page.set_viewport_size({'width':1560,'height':1000});page.click('[data-preset="l1"]');page.evaluate('Lab.advanceN(12000)');page.screenshot(path=str(p/'validation/r10_live_desktop.png'),full_page=True)
 result={'browser':b.version,'checks':checks,'pageErrors':errors,'console':console,'pass':all(x['pass']for x in checks)and not errors};(p/'validation/r10.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('Checks',len(checks),'pass',sum(x['pass']for x in checks),'Errors',errors);b.close()
