# 地月限制性三体问题实验室

运行只需 `earth_moon_lab.html`。打开文件，选择预设并点击运行；右上角可运行真实数值自检。

`VALIDATION.md` 包含模型、12轮记录、实测结果与局限。拆分源码和自动验证工具不参与页面运行。

重新构建：`python build.py`。内核检查：`node verify_core.js`。Python浏览器验证脚本使用真实Chromium，需要自行具备Python/Playwright/Chromium；独立参考还需numpy/scipy。

本包记录的导航被管理策略拦截；实际浏览器验证使用完整HTML set_content，HTTP服务另行确认200和相同哈希。详见报告，勿把它误称为本地导航已成功。
