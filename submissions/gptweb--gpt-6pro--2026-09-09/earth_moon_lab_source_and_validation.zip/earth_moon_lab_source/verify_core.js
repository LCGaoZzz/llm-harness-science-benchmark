'use strict';
const fs=require('fs');const T=require('./tests.js');
T.run().then(r=>{console.log(JSON.stringify(r,null,2));if(!r.pass)process.exitCode=1;}).catch(e=>{console.error(e);process.exitCode=1;});
